package com.naatdelay.dd7.ui.pedal

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.ui.components.PingPongToggle
import com.naatdelay.dd7.ui.components.RotaryKnob
import com.naatdelay.dd7.ui.components.StompSwitch
import com.naatdelay.dd7.ui.components.WaveformScrubber
import com.naatdelay.dd7.ui.export.ExportSheet
import com.naatdelay.dd7.ui.presets.PresetDrawer
import com.naatdelay.dd7.ui.settings.SettingsSheet
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography

@Composable
fun PedalScreen(viewModel: PedalViewModel) {
    val state by viewModel.uiState.collectAsState()
    val presets by viewModel.presets.collectAsState()
    val license by viewModel.licenseStatus.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    val colors = LocalPedalColors.current
    val context = LocalContext.current
    val screenHeightDp = LocalConfiguration.current.screenHeightDp
    val upperKnobSize = if (screenHeightDp < 700) 50.dp else 56.dp
    val modeKnobSize = if (screenHeightDp < 700) 64.dp else 72.dp
    val stompHeight = if (screenHeightDp < 700) 88.dp else 104.dp

    var showPresets by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val openAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.importAudio(uri)
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "ledPulse")
    val ledPulse by pulseTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ledAlpha"
    )

    val chassisBg by animateColorAsState(colors.bgChassis, label = "chassisBg")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(chassisBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // 1. Official Brownish-Bronze Premium Top System Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(colors.bronzeBarBg, Color(0xFF1A120C)))
                )
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BronzeSystemPill("Import", false, Modifier.weight(1f)) {
                openAudioLauncher.launch(
                    arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac", "audio/ogg", "audio/opus")
                )
            }
            BronzeSystemPill("Presets", showPresets, Modifier.weight(1f)) { showPresets = true }
            BronzeSystemPill("Export", showExport, Modifier.weight(1f)) { showExport = true }
            BronzeSystemPill("Theme", state.darkStudioTheme, Modifier.weight(1f)) { viewModel.toggleTheme() }
            BronzeSystemPill("Setting", showSettings, Modifier.weight(1f)) { showSettings = true }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            androidx.compose.animation.AnimatedVisibility(visible = state.statusBanner != null, enter = fadeIn(), exit = fadeOut()) {
                state.statusBanner?.let { msg ->
                    Text(
                        text = msg,
                        style = PedalTypography.captionMeta,
                        color = colors.statusWarning,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.statusWarning.copy(alpha = 0.14f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // 2. Waveform & Transport Card
            WaveformScrubber(
                trackName = if (state.isImporting) "Decoding audio..." else state.trackName,
                peaks = state.waveformPeaks,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                isPlaying = state.isPlaying,
                isLooping = state.isLooping,
                isLimiting = state.isLimiting,
                onTogglePlay = viewModel::togglePlayback,
                onToggleLoop = viewModel::toggleLoop,
                onSeekMs = viewModel::seekTo
            )

            // 3. Hardware DD-7X Pedal Chassis
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.verticalGradient(listOf(colors.pedalBodyTop, colors.pedalBodyBottom))
                    )
                    .border(2.dp, Color(0xFF8B929E), RoundedCornerShape(18.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Upper Cobalt Blue Stripe with Red CHECK LED + 3 Curved Knobs
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.pedalCobaltStripe)
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                ) {
                    // Subtle white hardware arc connecting the 3 upper knobs
                    Canvas(modifier = Modifier.matchParentSize()) {
                        drawArc(
                            color = Color.White.copy(alpha = 0.45f),
                            startAngle = 200f,
                            sweepAngle = 140f,
                            useCenter = false,
                            topLeft = Offset(size.width * 0.15f, size.height * 0.12f),
                            size = Size(size.width * 0.70f, size.height * 0.90f),
                            style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // CHECK LED top-left
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        val ledColor = when {
                            state.isTapTempoMode -> colors.ledTempoGreen
                            !state.isBypassed -> colors.ledActiveRed
                            else -> Color(0xFF3A414A)
                        }
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .alpha(if (!state.isBypassed || state.isTapTempoMode) ledPulse else 1f)
                                .clip(CircleShape)
                                .background(ledColor)
                                .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                        )
                        Text("CHECK", style = PedalTypography.knobLegend, color = Color.White)
                    }

                    // 3 Upper Knobs in a Gentle Downward Curve (outer knobs slightly lower, center slightly higher)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 18.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RotaryKnob(
                            label = "E.LEVEL",
                            value = state.effectLevel,
                            defaultValue = 0.48f,
                            readoutText = "${(state.effectLevel * 100).toInt()}%",
                            onValueChange = viewModel::setEffectLevel,
                            knobSize = upperKnobSize,
                            modifier = Modifier.offset(y = 8.dp)
                        )
                        RotaryKnob(
                            label = "F.BACK",
                            value = state.feedback / 0.95f,
                            defaultValue = 0.38f / 0.95f,
                            readoutText = "${(state.feedback * 100).toInt()}%",
                            onValueChange = { viewModel.setFeedback(it * 0.95f) },
                            knobSize = upperKnobSize,
                            modifier = Modifier.offset(y = (-4).dp)
                        )
                        val timeNorm = ((state.delayTimeMs - 1f) / (state.mode.maxMs - 1f)).coerceIn(0f, 1f)
                        RotaryKnob(
                            label = "D.TIME",
                            value = timeNorm,
                            defaultValue = (420f / state.mode.maxMs).coerceIn(0f, 1f),
                            readoutText = "${state.delayTimeMs.toInt()} ms",
                            onValueChange = viewModel::setDelayTimeNormalized,
                            knobSize = upperKnobSize,
                            modifier = Modifier.offset(y = 8.dp)
                        )
                    }
                }

                // Middle Section: Slightly Larger Central MODE Knob + Ping-Pong Stereo Toggle
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val modeColor = if (state.darkStudioTheme) Color(0xFFE6ECF5) else Color(0xFF1A1E24)
                    Text(
                        text = "MODE: ${state.mode.label}",
                        style = PedalTypography.monoReadout,
                        color = if (state.darkStudioTheme) colors.accentPingPong else colors.pedalCobaltStripe
                    )
                    RotaryKnob(
                        label = "MODE",
                        value = state.mode.ordinalCode.toFloat() / 5f,
                        defaultValue = UiDelayMode.ANALOG.ordinalCode.toFloat() / 5f,
                        readoutText = state.mode.label,
                        onValueChange = { norm ->
                            val idx = (norm * 5f).toInt().coerceIn(0, 5)
                            viewModel.setMode(UiDelayMode.entries[idx])
                        },
                        knobSize = modeKnobSize,
                        labelColor = modeColor,
                        arcColor = if (state.darkStudioTheme) colors.accentPingPong else colors.pedalCobaltStripe,
                        discreteSteps = 6
                    )

                    PingPongToggle(
                        enabled = state.isPingPong,
                        delayTimeMs = state.delayTimeMs,
                        onToggle = viewModel::togglePingPong
                    )
                }

                // Bottom Rubberized Stompbox Pad with Shiny "DD7X" + "developer : Shahid"
                StompSwitch(
                    isBypassed = state.isBypassed,
                    isTapTempoMode = state.isTapTempoMode,
                    onTap = viewModel::onStompTap,
                    onLongPressTapTempo = viewModel::onStompLongPress,
                    height = stompHeight
                )
            }
        }
    }

    if (showPresets) {
        PresetDrawer(
            presets = presets,
            activePresetId = state.activePresetId,
            onSelect = {
                viewModel.applyPreset(it)
                showPresets = false
            },
            onDelete = viewModel::deleteCustomPreset,
            onSaveNew = { name, overwrite -> viewModel.saveCustomPreset(name, overwrite) },
            onDismiss = { showPresets = false }
        )
    }

    if (showExport) {
        ExportSheet(
            defaultFileName = state.trackName.substringBeforeLast('.').ifBlank { "Naat_DD7X" } + "_DD7X",
            hasAudioLoaded = state.cachedPcmPath != null,
            isProActivated = license.isProActivated,
            exportState = exportState,
            onStartExport = { name, fmt -> viewModel.startExport(context, name, fmt) },
            onCancelExport = { viewModel.cancelExport(context) },
            onOpenActivation = {
                showExport = false
                showSettings = true
            },
            onDismiss = { showExport = false }
        )
    }

    if (showSettings) {
        SettingsSheet(
            licenseStatus = license,
            antiBoomCut = state.antiBoomCut,
            pingPongWidth = state.pingPongWidth,
            onAntiBoomChange = viewModel::setAntiBoomCut,
            onPingPongWidthChange = viewModel::setPingPongWidth,
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
private fun BronzeSystemPill(
    text: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalPedalColors.current
    val bg by animateColorAsState(
        targetValue = if (active) colors.bronzePillActive else colors.bronzePillBg,
        label = "bronzePill"
    )
    Box(
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(1.dp, colors.bronzeBorderGold.copy(alpha = if (active) 0.95f else 0.5f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = PedalTypography.captionMeta,
            color = colors.bronzeTextPrimary,
            maxLines = 1
        )
    }
}
