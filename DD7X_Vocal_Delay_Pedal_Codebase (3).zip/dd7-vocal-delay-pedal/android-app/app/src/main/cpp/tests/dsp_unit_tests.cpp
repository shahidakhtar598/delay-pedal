#include "dsp/DelayEngine.h"
#include "io/OfflineRenderer.h"
#include <atomic>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <vector>

using namespace dd7;

namespace {

void testHermiteDelayLine() {
    DelayLine dl;
    dl.prepare(48000.0, 500.0f);
    dl.push(1.0f);
    for (int i = 1; i < 100; ++i) dl.push(0.0f);
    const float tap = dl.readHermite(100.0f);
    assert(std::fabs(tap - 1.0f) < 1e-4f);
    std::cout << "[PASS] testHermiteDelayLine (tap=" << tap << ")\n";
}

void testMultiRepeatAudibilityAtHalfKnob() {
    DelayEngine engine;
    engine.prepare(48000.0);

    DspParamSnapshot p;
    p.effectLevel = 0.50f; // 12 o'clock
    p.feedback    = 0.50f; // 12 o'clock -> should produce 4+ clear audible repeats
    p.delayTimeMs = 200.0f; // 9600 frames
    p.mode        = DelayMode::ANALOG;
    p.pingPong    = false;

    // 1.5s buffer = 72000 frames; 100ms vocal tone burst at start
    std::vector<float> buf(72000 * 2, 0.0f);
    for (size_t i = 0; i < 4800; ++i) {
        const float s = 0.6f * std::sin(2.0f * 3.14159265f * 600.0f * static_cast<float>(i) / 48000.0f);
        buf[i * 2] = s;
        buf[i * 2 + 1] = s;
    }

    // Pre-settle delay smoother at 200ms
    std::vector<float> warmup(9600 * 2, 0.0f);
    engine.processInterleaved(warmup.data(), 9600, p);
    engine.processInterleaved(buf.data(), 72000, p);

    auto rmsWindow = [&](size_t startFrame, size_t len) {
        double sum = 0.0;
        for (size_t i = startFrame; i < startFrame + len; ++i) {
            sum += static_cast<double>(buf[i * 2]) * static_cast<double>(buf[i * 2]);
        }
        return std::sqrt(sum / static_cast<double>(len));
    };

    const double r1 = rmsWindow(9600, 4800);
    const double r2 = rmsWindow(19200, 4800);
    const double r3 = rmsWindow(28800, 4800);
    const double r4 = rmsWindow(38400, 4800);

    assert(r1 > 0.12);
    assert(r2 > 0.06);
    assert(r3 > 0.03);
    assert(r4 > 0.015);
    assert(r1 > r2 && r2 > r3 && r3 > r4); // Smooth natural decay
    std::cout << "[PASS] testMultiRepeatAudibility (R1=" << r1 << " R2=" << r2
              << " R3=" << r3 << " R4=" << r4 << ")\n";
}

void testPingPongAlternation() {
    DelayEngine engine;
    engine.prepare(48000.0);

    DspParamSnapshot p;
    p.effectLevel = 0.80f;
    p.feedback = 0.55f;
    p.delayTimeMs = 100.0f;
    p.mode = DelayMode::MS_200;
    p.pingPong = true;
    p.pingPongWidth = 1.0f;
    p.antiBoomCut = false;

    std::vector<float> warmup(9600 * 2, 0.0f);
    engine.processInterleaved(warmup.data(), 9600, p);

    std::vector<float> buf(16800 * 2, 0.0f);
    for (size_t i = 0; i < 500; ++i) {
        const float s = 0.5f * std::sin(2.0f * 3.14159265f * 440.0f * static_cast<float>(i) / 48000.0f);
        buf[i * 2] = s;
        buf[i * 2 + 1] = s;
    }

    engine.processInterleaved(buf.data(), 16800, p);

    float r1L = 0.0f, r1R = 0.0f, r2L = 0.0f, r2R = 0.0f;
    for (size_t i = 4800; i < 5300; ++i) {
        r1L += std::fabs(buf[i * 2]);
        r1R += std::fabs(buf[i * 2 + 1]);
    }
    for (size_t i = 9600; i < 10100; ++i) {
        r2L += std::fabs(buf[i * 2]);
        r2R += std::fabs(buf[i * 2 + 1]);
    }
    assert(r1L > r1R * 3.0f);
    assert(r2R > r2L * 3.0f);
    std::cout << "[PASS] testPingPongAlternation (R1 L=" << r1L << " R=" << r1R
              << " | R2 L=" << r2L << " R=" << r2R << ")\n";
}

void testSoftLimiterAndZeroGlitchStress() {
    DelayEngine engine;
    engine.prepare(48000.0);

    DspParamSnapshot p;
    p.effectLevel = 1.0f;
    p.feedback = 1.5f; // Abusive input -> safely clamped
    p.delayTimeMs = 80.0f;
    p.mode = DelayMode::ANALOG;

    std::vector<float> buf(48000 * 2, 0.0f);
    for (size_t i = 0; i < 48000; ++i) {
        const float s = 0.95f * std::sin(2.0f * 3.14159265f * 1000.0f * static_cast<float>(i) / 48000.0f);
        buf[i * 2] = s;
        buf[i * 2 + 1] = s;
    }

    const float peak = engine.processInterleaved(buf.data(), 48000, p);
    assert(std::isfinite(peak));
    assert(peak <= 0.967f);
    for (float s : buf) {
        assert(std::isfinite(s));
        assert(std::fabs(s) <= 0.967f);
    }
    std::cout << "[PASS] testSoftLimiterAndZeroGlitchStress (peak=" << peak << ")\n";
}

void testOfflineRendererWavAndTail() {
    const std::string inPath = "/tmp/dd7_test_input.pcm";
    const std::string outPath = "/tmp/dd7_test_output.wav";

    std::vector<float> dry(48000 * 2, 0.0f);
    for (size_t i = 0; i < 48000; ++i) {
        const float env = (i < 24000) ? 0.6f : 0.0f;
        const float s = env * std::sin(2.0f * 3.14159265f * 440.0f * static_cast<float>(i) / 48000.0f);
        dry[i * 2] = s;
        dry[i * 2 + 1] = s;
    }
    std::FILE* f = std::fopen(inPath.c_str(), "wb");
    assert(f != nullptr);
    std::fwrite(dry.data(), sizeof(float), dry.size(), f);
    std::fclose(f);

    OfflineExportConfig cfg;
    cfg.inputPcmPath = inPath;
    cfg.outputFilePath = outPath;
    cfg.sampleRate = 48000;
    cfg.format = ExportFormat::WAV_16;
    cfg.maxDurationSec = -1;
    cfg.dspParams.effectLevel = 0.6f;
    cfg.dspParams.feedback = 0.50f;
    cfg.dspParams.delayTimeMs = 300.0f;
    cfg.dspParams.mode = DelayMode::MODULATE;
    cfg.dspParams.pingPong = true;

    std::atomic<bool> cancel{false};
    int lastPct = 0;
    const auto res = OfflineRenderer::render(cfg, cancel, [&](int32_t pct) { lastPct = pct; });

    assert(res.success);
    assert(lastPct == 100);
    assert(res.tailMs >= 500);
    assert(res.fileBytes > 44 + 48000 * 4);

    std::remove(inPath.c_str());
    std::remove(outPath.c_str());
    std::cout << "[PASS] testOfflineRendererWavAndTail (bytes=" << res.fileBytes
              << ", tailMs=" << res.tailMs << ")\n";
}

} // namespace

int main() {
    testHermiteDelayLine();
    testMultiRepeatAudibilityAtHalfKnob();
    testPingPongAlternation();
    testSoftLimiterAndZeroGlitchStress();
    testOfflineRendererWavAndTail();
    std::cout << "ALL C++20 DSP & OFFLINE RENDERER TESTS PASSED!\n";
    return 0;
}
