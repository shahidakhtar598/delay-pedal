#include "dsp/AnalogFilter.h"
#include <algorithm>
#include <cmath>

namespace dd7 {

namespace {
constexpr double kPi = 3.14159265358979323846;

float onePoleCoeff(double sampleRate, double cutoffHz) {
    return static_cast<float>(1.0 - std::exp(-2.0 * kPi * cutoffHz / sampleRate));
}
} // namespace

void Biquad::setHighPass(double sampleRate, double freqHz, double q) {
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha;

    b0 = static_cast<float>(((1.0 + cosW0) * 0.5) / a0);
    b1 = static_cast<float>((-(1.0 + cosW0)) / a0);
    b2 = static_cast<float>(((1.0 + cosW0) * 0.5) / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha) / a0);
}

void Biquad::setLowPass(double sampleRate, double freqHz, double q) {
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha;

    b0 = static_cast<float>(((1.0 - cosW0) * 0.5) / a0);
    b1 = static_cast<float>((1.0 - cosW0) / a0);
    b2 = static_cast<float>(((1.0 - cosW0) * 0.5) / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha) / a0);
}

void Biquad::setNotch(double sampleRate, double freqHz, double q) {
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha;

    b0 = static_cast<float>(1.0 / a0);
    b1 = static_cast<float>((-2.0 * cosW0) / a0);
    b2 = static_cast<float>(1.0 / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha) / a0);
}

void AnalogFilter::prepare(double sampleRate) {
    hpf180_.setHighPass(sampleRate, 180.0, 0.7071);
    notch360_.setNotch(sampleRate, 360.0, 2.0);
    fbHpf80_.setHighPass(sampleRate, 80.0, 0.7071);

    digitalLpCoeff_ = onePoleCoeff(sampleRate, 9500.0);
    analogLpCoeff_  = onePoleCoeff(sampleRate, 3800.0);
    reset();
}

void AnalogFilter::reset() noexcept {
    hpf180_.reset();
    notch360_.reset();
    fbHpf80_.reset();
    lpState_ = 0.0f;
}

float AnalogFilter::processWetInput(float x, bool antiBoomEnabled) noexcept {
    if (!std::isfinite(x)) return 0.0f;
    if (!antiBoomEnabled) return x;
    return notch360_.process(hpf180_.process(x));
}

float AnalogFilter::processFeedback(float x, bool analogMode) noexcept {
    if (!std::isfinite(x)) return 0.0f;

    // Remove DC/sub-80Hz buildup so high-feedback tails never crackle on phone speakers
    float y = fbHpf80_.process(x);

    // Smooth 1-pole roll-off (preserves vocal presence across 5-8 repeats)
    const float coeff = analogMode ? analogLpCoeff_ : digitalLpCoeff_;
    lpState_ += coeff * (y - lpState_);
    y = lpState_;

    // Clean soft-saturation headroom guard inside feedback loop (prevents internal overload/crackle)
    if (analogMode) {
        y = std::tanh(y * 1.10f) / 1.10f;
    } else if (std::fabs(y) > 0.85f) {
        y = 0.85f + 0.15f * std::tanh((y - (y > 0.0f ? 0.85f : -0.85f)) / 0.15f);
    }
    return y;
}

} // namespace dd7
