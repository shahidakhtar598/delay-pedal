#pragma once

#include "dsp/DspParams.h"
#include "dsp/DelayLine.h"
#include "dsp/AnalogFilter.h"
#include "dsp/ModLfo.h"
#include "dsp/PingPongMatrix.h"
#include "dsp/SoftLimiter.h"
#include <cstddef>

namespace dd7 {

class DelayEngine {
public:
    void prepare(double sampleRate);
    void reset() noexcept;

    float processInterleaved(float* stereoBuffer, size_t frameCount, const DspParamSnapshot& params) noexcept;

    bool isLimiting() const noexcept { return limiter_.didLimitRecently(); }
    double sampleRate() const noexcept { return sampleRate_; }

private:
    double sampleRate_ = 48000.0;

    DelayLine delayL_;
    DelayLine delayR_;
    AnalogFilter filterL_;
    AnalogFilter filterR_;
    ModLfo modLfo_;
    SoftLimiter limiter_;

    float smoothCoeff_ = 0.001f;
    float delaySmoothCoeff_ = 0.0006f;
    float smoothEffectGain_ = 0.0f;
    float smoothFeedback_ = 0.55f;
    float smoothDelaySamples_ = 20160.0f;
    float smoothWetSend_ = 1.0f;
};

} // namespace dd7
