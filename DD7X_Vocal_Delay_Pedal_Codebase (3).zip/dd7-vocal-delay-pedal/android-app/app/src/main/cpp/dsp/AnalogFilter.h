#pragma once

namespace dd7 {

struct Biquad {
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f;
    float a1 = 0.0f, a2 = 0.0f;
    float z1 = 0.0f, z2 = 0.0f;

    void reset() noexcept { z1 = 0.0f; z2 = 0.0f; }

    inline float process(float x) noexcept {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void setHighPass(double sampleRate, double freqHz, double q = 0.7071);
    void setLowPass(double sampleRate, double freqHz, double q = 0.7071);
    void setNotch(double sampleRate, double freqHz, double q = 2.0);
};

class AnalogFilter {
public:
    void prepare(double sampleRate);
    void reset() noexcept;

    // Input conditioning on wet send: 180 Hz HPF + 360 Hz Anti-Boom Notch
    float processWetInput(float x, bool antiBoomEnabled) noexcept;

    // Feedback-loop conditioning:
    // - Subtle 80 Hz DC/rumble blocker prevents low-end crackle buildup on long tails
    // - Digital/Modulate: gentle 1-pole 9.5 kHz damping (keeps 5-8 repeats crystal clear)
    // - Analog: smooth 1-pole 3.8 kHz warm BBD roll-off + gentle saturation
    float processFeedback(float x, bool analogMode) noexcept;

private:
    Biquad hpf180_;
    Biquad notch360_;
    Biquad fbHpf80_;

    float digitalLpCoeff_ = 0.5f;
    float analogLpCoeff_  = 0.3f;
    float lpState_        = 0.0f;
};

} // namespace dd7
