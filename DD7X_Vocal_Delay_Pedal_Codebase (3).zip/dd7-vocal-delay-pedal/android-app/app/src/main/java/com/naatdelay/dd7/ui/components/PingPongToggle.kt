package com.naatdelay.dd7.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography
import kotlinx.coroutines.delay

@Composable
fun PingPongToggle(
    enabled: Boolean,
    delayTimeMs: Float,
    darkText: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalPedalColors.current
    val haptic = LocalHapticFeedback.current
    var bounceLeft by remember { mutableStateOf(true) }

    LaunchedEffect(enabled, delayTimeMs) {
        if (!enabled) return@LaunchedEffect
        val intervalMs = delayTimeMs.toLong().coerceIn(140L, 1000L)
        while (true) {
            delay(intervalMs)
            bounceLeft = !bounceLeft
        }
    }

    val trackColor by animateColorAsState(
        targetValue = if (enabled) Color(0xFF0B2A30) else Color(0xFF1B1F26),
        label = "ppTrack"
    )
    val thumbOffset by animateDpAsState(
        targetValue = if (enabled) 24.dp else 4.dp,
        animationSpec = spring(),
        label = "ppThumb"
    )
    val thumbColor by animateColorAsState(
        targetValue = if (enabled) {
            if (bounceLeft) colors.accentPingPong else Color(0xFF4DD0E1)
        } else Color(0xFF6B7380),
        label = "ppGlow"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .width(50.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(trackColor)
                .border(1.5.dp, if (enabled) colors.accentPingPong else Color(0xFF454C57), RoundedCornerShape(13.dp))
                .clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onToggle()
                },
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .offset(x = thumbOffset)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(thumbColor)
            )
        }

        Text(
            text = "PING-PONG
STEREO",
            style = PedalTypography.knobLegend.copy(fontSize = 9.sp, lineHeight = 11.sp),
            color = if (enabled) colors.accentPingPong else if (darkText) Color(0xFF1A1E24) else Color(0xFFE0E6EE),
            textAlign = TextAlign.Center
        )
    }
}
