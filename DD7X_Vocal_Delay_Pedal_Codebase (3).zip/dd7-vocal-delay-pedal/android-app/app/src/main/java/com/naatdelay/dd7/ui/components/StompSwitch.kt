package com.naatdelay.dd7.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.naatdelay.dd7.ui.theme.PedalTypography

@Composable
fun StompSwitch(
    isBypassed: Boolean,
    isTapTempoMode: Boolean,
    onTap: () -> Unit,
    onLongPressTapTempo: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 152.dp
) {
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.975f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "stompScale"
    )

    val chromeBrush = Brush.verticalGradient(
        listOf(
            Color(0xFFFFFFFF),
            Color(0xFFE3E8EF),
            Color(0xFF8C96A5),
            Color(0xFFF6F9FC)
        )
    )

    // Outer recessed stomp bezel
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0E1014))
            .border(2.dp, Color(0xFF3E444F), RoundedCornerShape(16.dp))
            .padding(5.dp)
    ) {
        // Inner rubberized textured stomp pad
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height - 10.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF23262E), Color(0xFF16181D), Color(0xFF0F1115))
                    )
                )
                .border(1.dp, Color(0xFF343A44), RoundedCornerShape(12.dp))
                .pointerInput(isTapTempoMode) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onTap()
                        },
                        onLongPress = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onLongPressTapTempo()
                        }
                    )
                }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "DD7X",
                    style = TextStyle(
                        brush = chromeBrush,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        fontSize = 44.sp,
                        letterSpacing = 4.sp,
                        shadow = Shadow(
                            color = Color(0xCC000000),
                            offset = Offset(0f, 5f),
                            blurRadius = 10f
                        )
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "developer : Shahid",
                    style = PedalTypography.captionMeta.copy(
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        letterSpacing = 0.8.sp
                    ),
                    color = Color(0xFFB4BCC8)
                )
            }
        }
    }
}
