package com.naatdelay.dd7.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.data.repository.LicenseUiStatus
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    licenseStatus: LicenseUiStatus,
    antiBoomCut: Boolean,
    pingPongWidth: Float,
    onAntiBoomChange: (Boolean) -> Unit,
    onPingPongWidthChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalPedalColors.current
    val deviceId = licenseStatus.deviceIdentity?.shortId ?: "SHD-0000-0000"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = colors.bronzeSheetBg,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("App Settings", style = PedalTypography.headingSheet, color = colors.bronzeTextPrimary)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.bronzeCardBg)
                    .border(1.dp, colors.bronzeBorderGold.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text("Pro License Active (Lifetime)", style = PedalTypography.bodyPrimary, color = colors.ledTempoGreen)
                Text("User ID: $deviceId", style = PedalTypography.monoReadout, color = colors.bronzeTextPrimary)
                if (licenseStatus.userProfile.fullName.isNotBlank()) {
                    Text(
                        "Registered: ${licenseStatus.userProfile.fullName} (@${licenseStatus.userProfile.username})",
                        style = PedalTypography.captionMeta,
                        color = colors.bronzeTextMuted
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.bronzeCardBg)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Anti-Boom Vocal Cut", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                    Text("180 Hz HPF + 360 Hz notch on wet repeats", style = PedalTypography.captionMeta, color = colors.bronzeTextMuted)
                }
                Switch(
                    checked = antiBoomCut,
                    onCheckedChange = onAntiBoomChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colors.bronzeTextPrimary,
                        checkedTrackColor = colors.bronzeBorderGold
                    )
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.bronzeCardBg)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Ping-Pong Stereo Width", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                    Text("${(pingPongWidth * 100).toInt()}%", style = PedalTypography.monoReadout, color = colors.bronzeBorderGold)
                }
                Slider(
                    value = pingPongWidth,
                    onValueChange = onPingPongWidthChange,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.bronzeBorderGold,
                        activeTrackColor = colors.bronzeBorderGold
                    )
                )
            }
        }
    }
}
