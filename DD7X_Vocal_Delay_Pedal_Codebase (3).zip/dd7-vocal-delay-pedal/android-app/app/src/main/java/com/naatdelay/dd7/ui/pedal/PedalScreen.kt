package com.naatdelay.dd7.ui.pedal

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.naatdelay.dd7.ui.components.PingPongToggle
import com.naatdelay.dd7.ui.components.RotaryKnob
import com.naatdelay.dd7.ui.components.StompSwitch
import com.naatdelay.dd7.ui.components.WaveformScrubber
import com.naatdelay.dd7.ui.export.ExportSheet
import com.naatdelay.dd7.ui.presets.PresetDrawer
import com.naatdelay.dd7.ui.settings.SettingsSheet
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PedalScreen(viewModel: PedalViewModel) {
    val state by viewModel.uiState.collectAsState()
    val presets by viewModel.presets.collectAsState()
    val license by viewModel.licenseStatus.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    val colors = LocalPedalColors.current
    val context = LocalContext.current
    val screenHeightDp = LocalConfiguration.current.screenHeightDp
    val upperKnobSize = if (screenHeightDp < 700) 54.dp else 64.dp
    val modeKnobSize = if (screenHeightDp < 700) 64.dp else 74.dp
    val stompHeight = if (screenHeightDp < 700) 114.dp else 148.dp

    var showPresets by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val openAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.importAudio(uri)
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "ledPulse")
    val ledPulse by pulseTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ledAlpha"
    )

    val chassisBg by animateColorAsState(colors.bgChassis, label = "chassisBg")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(chassisBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // 1. Official Brownish-Bronze Premium Top System Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(colors.bronzeBarBg, Color(0xFF1A120C)))
                )
                .padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BronzeSystemPill("Import", false, Modifier.weight(1f)) {
                openAudioLauncher.launch(
                    arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac", "audio/ogg", "audio/opus")
                )
            }
            BronzeSystemPill("Presets", showPresets, Modifier.weight(1f)) { showPresets = true }
            BronzeSystemPill("Export", showExport, Modifier.weight(1f)) { showExport = true }
            BronzeSystemPill("Theme", state.darkStudioTheme, Modifier.weight(1f)) { viewModel.toggleTheme() }
            BronzeSystemPill("Setting", showSettings, Modifier.weight(1f)) { showSettings = true }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            androidx.compose.animation.AnimatedVisibility(visible = state.statusBanner != null, enter = fadeIn(), exit = fadeOut()) {
                state.statusBanner?.let { msg ->
                    Text(
                        text = msg,
                        style = PedalTypography.captionMeta,
                        color = colors.statusWarning,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.statusWarning.copy(alpha = 0.14f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // 2. Waveform & Transport Card
            WaveformScrubber(
                trackName = if (state.isImporting) "Decoding audio..." else state.trackName,
                peaks = state.waveformPeaks,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                isPlaying = state.isPlaying,
                isLooping = state.isLooping,
                isLimiting = state.isLimiting,
                onTogglePlay = viewModel::togglePlayback,
                onToggleLoop = viewModel::toggleLoop,
                onSeekMs = viewModel::seekTo
            )

            // 3. Hardware DD-7X Pedal Chassis
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.verticalGradient(listOf(colors.pedalBodyTop, colors.pedalBodyBottom))
                    )
                    .border(2.dp, Color(0xFF7D8592), RoundedCornerShape(18.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Upper Cobalt Blue Stripe with Screws, Red CHECK LED + 3 Curved Knobs
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1E65D0), colors.pedalCobaltStripe, Color(0xFF104194))
                            )
                        )
                        .padding(horizontal = 10.dp, vertical = 10.dp)
                ) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        // Top-left & top-right hardware screws
                        drawScrewHead(Offset(10.dp.toPx(), 10.dp.toPx()), 6.dp.toPx())
                        drawScrewHead(Offset(size.width - 10.dp.toPx(), 10.dp.toPx()), 6.dp.toPx())

                        // Subtle curved hardware arc connecting the 3 upper knobs
                        drawArc(
                            color = Color.White.copy(alpha = 0.45f),
                            startAngle = 200f,
                            sweepAngle = 140f,
                            useCenter = false,
                            topLeft = Offset(size.width * 0.14f, size.height * 0.12f),
                            size = Size(size.width * 0.72f, size.height * 0.85f),
                            style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // CHECK LED
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = 22.dp, top = 2.dp)
                    ) {
                        val ledColor = when {
                            state.isTapTempoMode -> colors.ledTempoGreen
                            !state.isBypassed -> colors.ledActiveRed
                            else -> Color(0xFF3A414A)
                        }
                        Box(
                            modifier = Modifier
                                .size(11.dp)
                                .alpha(if (!state.isBypassed || state.isTapTempoMode) ledPulse else 1f)
                                .clip(CircleShape)
                                .background(ledColor)
                                .border(1.dp, Color.White.copy(alpha = 0.65f), CircleShape)
                        )
                        Text("CHECK", style = PedalTypography.knobLegend, color = Color.White)
                    }

                    // 3 Upper Knobs in a Gentle Curve
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RotaryKnob(
                            label = "E.LEVEL",
                            value = state.effectLevel,
                            defaultValue = 0.48f,
                            readoutText = "${(state.effectLevel * 100).toInt()}%",
                            onValueChange = viewModel::setEffectLevel,
                            knobSize = upperKnobSize,
                            modifier = Modifier.offset(y = 8.dp)
                        )
                        RotaryKnob(
                            label = "F.BACK",
                            value = state.feedback / 0.95f,
                            defaultValue = 0.38f / 0.95f,
                            readoutText = "${(state.feedback * 100).toInt()}%",
                            onValueChange = { viewModel.setFeedback(it * 0.95f) },
                            knobSize = upperKnobSize,
                            modifier = Modifier.offset(y = (-6).dp)
                        )
                        val timeNorm = ((state.delayTimeMs - 1f) / (state.mode.maxMs - 1f)).coerceIn(0f, 1f)
                        RotaryKnob(
                            label = "D.TIME",
                            value = timeNorm,
                            defaultValue = (420f / state.mode.maxMs).coerceIn(0f, 1f),
                            readoutText = "${state.delayTimeMs.toInt()} ms",
                            onValueChange = viewModel::setDelayTimeNormalized,
                            knobSize = upperKnobSize,
                            modifier = Modifier.offset(y = 8.dp)
                        )
                    }
                }

                // Middle Section: Central MODE Dial with 6 Radial Detent Labels + Right-Side Ping-Pong Switch + Lower Screws
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val labelColor = if (state.darkStudioTheme) Color(0xFFE6ECF5) else Color(0xFF1A1E24)
                    val activeAccent = if (state.darkStudioTheme) colors.accentPingPong else colors.pedalCobaltStripe

                    // Lower chassis corner screws
                    Canvas(modifier = Modifier.matchParentSize()) {
                        drawScrewHead(Offset(10.dp.toPx(), size.height - 10.dp.toPx()), 6.dp.toPx())
                        drawScrewHead(Offset(size.width - 10.dp.toPx(), size.height - 10.dp.toPx()), 6.dp.toPx())
                    }

                    // Central MODE Dial + Radial Labels
                    Box(
                        modifier = Modifier.align(Alignment.Center),
                        contentAlignment = Alignment.Center
                    ) {
                        val modes = UiDelayMode.entries
                        val anglesDeg = listOf(165f, 200f, 235f, 270f, 305f, 340f)

                        // Radial detent dots & crisp text labels around MODE knob
                        modes.forEachIndexed { idx, m ->
                            val rad = anglesDeg[idx] * (PI / 180.0)
                            val radiusDp = 66f
                            val dx = (radiusDp * cos(rad)).dp
                            val dy = (radiusDp * sin(rad) - 4f).dp
                            val isSelected = state.mode == m
                            Text(
                                text = m.label,
                                style = PedalTypography.knobLegend.copy(
                                    fontSize = 9.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    letterSpacing = 0.2.sp
                                ),
                                color = if (isSelected) activeAccent else labelColor.copy(alpha = 0.78f),
                                modifier = Modifier
                                    .offset(x = dx, y = dy)
                                    .clickable { viewModel.setMode(m) }
                            )
                        }

                        RotaryKnob(
                            label = "MODE",
                            value = state.mode.ordinalCode.toFloat() / 5f,
                            defaultValue = UiDelayMode.ANALOG.ordinalCode.toFloat() / 5f,
                            readoutText = state.mode.label,
                            onValueChange = { norm ->
                                val idx = (norm * 5f).toInt().coerceIn(0, 5)
                                viewModel.setMode(UiDelayMode.entries[idx])
                            },
                            knobSize = modeKnobSize,
                            labelColor = labelColor,
                            arcColor = activeAccent,
                            discreteSteps = 6
                        )
                    }

                    // Right-side Compact PING-PONG STEREO Switch (matching mockup)
                    PingPongToggle(
                        enabled = state.isPingPong,
                        delayTimeMs = state.delayTimeMs,
                        darkText = !state.darkStudioTheme,
                        onToggle = viewModel::togglePingPong,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 12.dp, bottom = 14.dp)
                    )
                }

                // Bottom Rubberized Stompbox Pad with Big Shiny "DD7X" + "developer : Shahid"
                StompSwitch(
                    isBypassed = state.isBypassed,
                    isTapTempoMode = state.isTapTempoMode,
                    onTap = viewModel::onStompTap,
                    onLongPressTapTempo = viewModel::onStompLongPress,
                    height = stompHeight
                )
            }
        }
    }

    if (showPresets) {
        PresetDrawer(
            presets = presets,
            activePresetId = state.activePresetId,
            onSelect = {
                viewModel.applyPreset(it)
                showPresets = false
            },
            onDelete = viewModel::deleteCustomPreset,
            onSaveNew = { name, overwrite -> viewModel.saveCustomPreset(name, overwrite) },
            onDismiss = { showPresets = false }
        )
    }

    if (showExport) {
        ExportSheet(
            defaultFileName = state.trackName.substringBeforeLast('.').ifBlank { "Naat_DD7X" } + "_DD7X",
            hasAudioLoaded = state.cachedPcmPath != null,
            isProActivated = license.isProActivated,
            exportState = exportState,
            onStartExport = { name, fmt -> viewModel.startExport(context, name, fmt) },
            onCancelExport = { viewModel.cancelExport(context) },
            onOpenActivation = {
                showExport = false
                showSettings = true
            },
            onDismiss = { showExport = false }
        )
    }

    if (showSettings) {
        SettingsSheet(
            licenseStatus = license,
            antiBoomCut = state.antiBoomCut,
            pingPongWidth = state.pingPongWidth,
            onAntiBoomChange = viewModel::setAntiBoomCut,
            onPingPongWidthChange = viewModel::setPingPongWidth,
            onDismiss = { showSettings = false }
        )
    }
}

private fun DrawScope.drawScrewHead(center: Offset, radius: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFD5DCE6), Color(0xFF6B7380)),
            center = center,
            radius = radius
        ),
        radius = radius,
        center = center
    )
    val d = radius * 0.52f
    drawLine(Color(0xFF2B3038), Offset(center.x - d, center.y - d), Offset(center.x + d, center.y + d), strokeWidth = 1.4f)
    drawLine(Color(0xFF2B3038), Offset(center.x + d, center.y - d), Offset(center.x - d, center.y + d), strokeWidth = 1.4f)
}

@Composable
private fun BronzeSystemPill(
    text: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalPedalColors.current
    val bg by animateColorAsState(
        targetValue = if (active) colors.bronzePillActive else colors.bronzePillBg,
        label = "bronzePill"
    )
    Box(
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(1.dp, colors.bronzeBorderGold.copy(alpha = if (active) 0.95f else 0.55f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = PedalTypography.captionMeta,
            color = colors.bronzeTextPrimary,
            maxLines = 1
        )
    }
}
