package com.naatdelay.dd7.ui.activation

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.naatdelay.dd7.BuildConfig
import com.naatdelay.dd7.R
import com.naatdelay.dd7.data.repository.LicenseRepository
import com.naatdelay.dd7.data.repository.LicenseUiStatus
import com.naatdelay.dd7.licensing.ActivationApiResult
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography
import kotlinx.coroutines.launch

private data class GuideLanguage(val label: String, val paragraph: String)

private fun buildUnlockParagraphs(priceInr: String): List<GuideLanguage> = listOf(
    GuideLanguage(
        "English",
        "Lifetime Price: ₹$priceInr only. To unlock DD-7X Vocal Delay permanently, scan the Bank QR code below (₹$priceInr auto-filled) or tap Pay via UPI, then send the payment screenshot with your User ID to our WhatsApp number. You will receive your personal Token — paste it below to unlock all features for lifetime."
    ),
    GuideLanguage(
        "Hinglish",
        "Lifetime Price: sirf ₹$priceInr. DD-7X Vocal Delay ko lifetime unlock karne ke liye neeche diye gaye Bank QR code ko scan karke ₹$priceInr pay karein aur payment screenshot ke sath apna User ID hamare WhatsApp par bhejein. Aapko aapka personal Token milega — use neeche Token box mein paste karte hi app ke saare features lifetime unlock ho jayenge."
    ),
    GuideLanguage(
        "اردو",
        "لائف ٹائم قیمت: صرف ₹$priceInr۔ DD-7X Vocal Delay کو ہمیشہ کے لیے ان لاک کرنے کے لیے نیچے دیے گئے بینک QR کوڈ کو اسکین کر کے ₹$priceInr ادا کریں اور اسکرین شاٹ اور اپنا User ID ہمارے واٹس ایپ پر بھیجیں۔ آپ کو ذاتی ٹوکن ملے گا — اسے نیچے ٹوکن باکس میں پیسٹ کریں اور تمام فیچرز ان لاک کر لیں۔"
    ),
    GuideLanguage(
        "हिन्दी",
        "लाइफटाइम कीमत: केवल ₹$priceInr। DD-7X Vocal Delay को हमेशा के लिए अनलॉक करने के लिए नीचे दिए गए बैंक QR कोड को स्कैन करके ₹$priceInr का पेमेंट करें और स्क्रीनशॉट व अपना User ID हमारे व्हाट्सएप पर भेजें। आपको आपका पर्सनल टोकन मिलेगा — उसे नीचे टोकन बॉक्स में पेस्ट करते ही सभी फीचर्स अनलॉक हो जाएंगे।"
    ),
    GuideLanguage(
        "தமிழ்",
        "வாழ்நாள் கட்டணம்: ₹$priceInr மட்டுமே. DD-7X Vocal Delay செயலியை வாழ்நாள் முழுவதும் திறக்க, கீழே உள்ள வங்கி QR குறியீட்டை ஸ்கேன் செய்து ₹$priceInr செலுத்துங்கள். பின்னர் கட்டண ரசீது மற்றும் உங்கள் User ID-ஐ எங்கள் WhatsApp எண்ணிற்கு அனுப்புங்கள். உங்களுக்கு வழங்கப்படும் Token-ஐ கீழே உள்ளிட்டால் அனைத்து வசதிகளும் திறக்கப்படும்."
    ),
    GuideLanguage(
        "বাংলা",
        "লাইফটাইম মূল্য: মাত্র ₹$priceInr। DD-7X Vocal Delay আজীবনের জন্য আনলক করতে নিচের ব্যাংক QR কোড স্ক্যান করে ₹$priceInr পেমেন্ট করুন এবং স্ক্রিনশট ও আপনার User ID আমাদের হোয়াটসঅ্যাপে পাঠান। আপনাকে একটি পার্সোনাল টোকেন দেওয়া হবে — নিচের টোকেন বক্সে সেটি পেস্ট করলেই সব ফিচার আনলক হয়ে যাবে।"
    ),
    GuideLanguage(
        "മലയാളം",
        "ലൈഫ് ടൈം വില: ₹$priceInr മാത്രം. DD-7X Vocal Delay ആജീവനാന്തം അൺലോക്ക് ചെയ്യാൻ താഴെയുള്ള ബാങ്ക് QR കോഡ് സ്കാൻ ചെയ്ത് ₹$priceInr അടയ്ക്കുക. തുടർന്ന് പേയ്‌മെന്റ് സ്ക്രീൻഷോട്ടും നിങ്ങളുടെ User ID-യും ഞങ്ങളുടെ വാട്ട്‌സ്ആപ്പിലേക്ക് അയക്കുക. ലഭിക്കുന്ന ടോക്കൺ താഴെ നൽകിയാൽ എല്ലാ ഫീച്ചറുകളും അൺലോക്ക് ആകും."
    )
)

private fun generateUpiQrBitmap(upiUri: String, sizePx: Int = 512): Bitmap? {
    return try {
        val matrix = QRCodeWriter().encode(upiUri, BarcodeFormat.QR_CODE, sizePx, sizePx)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
        bmp
    } catch (_: Throwable) {
        null
    }
}

@Composable
fun OnboardingUnlockFlow(
    licenseRepo: LicenseRepository,
    licenseStatus: LicenseUiStatus
) {
    val colors = LocalPedalColors.current
    var currentStep by remember(licenseStatus.userProfile.isRegistered) {
        mutableIntStateOf(if (licenseStatus.userProfile.isRegistered) 1 else 0)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.lightBrownBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(colors.lightBrownField)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            GateTabPill("1. Account Login", currentStep == 0, Modifier.weight(1f)) {
                currentStep = 0
            }
            GateTabPill("2. Payment & Unlock", currentStep == 1, Modifier.weight(1f)) {
                if (licenseStatus.userProfile.isRegistered) currentStep = 1
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        AnimatedContent(
            targetState = currentStep,
            transitionSpec = {
                (slideInHorizontally { if (targetState > initialState) it else -it } + fadeIn()) togetherWith
                    (slideOutHorizontally { if (targetState > initialState) -it else it } + fadeOut())
            },
            label = "gateFlowTransition"
        ) { step ->
            if (step == 0) {
                RegistrationLoginStep(
                    initialPhone = licenseStatus.userProfile.phone,
                    initialName = licenseStatus.userProfile.fullName,
                    initialUsername = licenseStatus.userProfile.username,
                    onContinue = { phone, name, username, password ->
                        licenseRepo.saveRegistration(phone, name, username, password)
                        currentStep = 1
                    }
                )
            } else {
                PaymentAndUnlockStep(
                    licenseRepo = licenseRepo,
                    licenseStatus = licenseStatus
                )
            }
        }
    }
}

@Composable
private fun RegistrationLoginStep(
    initialPhone: String,
    initialName: String,
    initialUsername: String,
    onContinue: (String, String, String, String) -> Unit
) {
    val colors = LocalPedalColors.current
    var phone by remember { mutableStateOf(initialPhone) }
    var fullName by remember { mutableStateOf(initialName) }
    var username by remember { mutableStateOf(initialUsername) }
    var password by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = colors.lightBrownText,
        unfocusedTextColor = colors.lightBrownText,
        focusedBorderColor = colors.lightBrownAccent,
        unfocusedBorderColor = colors.lightBrownAccent.copy(alpha = 0.4f),
        focusedContainerColor = colors.lightBrownCard,
        unfocusedContainerColor = colors.lightBrownCard
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .clip(RoundedCornerShape(20.dp))
            .background(colors.lightBrownCard)
            .border(1.dp, colors.lightBrownAccent.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("DD-7X Vocal Delay", style = PedalTypography.displayBrand, color = colors.lightBrownAccent)
        Text(
            "Create your account to continue to payment (₹${BuildConfig.APP_PRICE_INR} Lifetime) and activation.",
            style = PedalTypography.bodyPrimary,
            color = colors.lightBrownSubtext
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it.filter { ch -> ch.isDigit() || ch == '+' }.take(15); errorMsg = null },
            label = { Text("Mobile Number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it; errorMsg = null },
            label = { Text("Full Name") },
            singleLine = true,
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = username,
            onValueChange = { username = it.trim(); errorMsg = null },
            label = { Text("Username") },
            singleLine = true,
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMsg = null },
            label = { Text("Password (minimum 7 characters)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth()
        )

        androidx.compose.animation.AnimatedVisibility(visible = errorMsg != null) {
            Text(errorMsg.orEmpty(), style = PedalTypography.captionMeta, color = colors.ledActiveRed)
        }

        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = {
                when {
                    phone.length < 10 -> errorMsg = "Please enter a valid 10+ digit mobile number."
                    fullName.isBlank() -> errorMsg = "Please enter your full name."
                    username.length < 3 -> errorMsg = "Username must be at least 3 characters."
                    password.length < 7 -> errorMsg = "Password must be at least 7 characters."
                    else -> onContinue(phone, fullName, username, password)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = colors.lightBrownAccent),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("Save & Go to Payment Page", color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PaymentAndUnlockStep(
    licenseRepo: LicenseRepository,
    licenseStatus: LicenseUiStatus
) {
    val colors = LocalPedalColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val priceInr = BuildConfig.APP_PRICE_INR.ifBlank { "249" }
    val upiId = BuildConfig.FOUNDER_UPI_ID.trim()
    val userId = licenseStatus.deviceIdentity?.shortId ?: "SHD-0000-0000"

    val upiUri = remember(upiId, priceInr, userId) {
        if (upiId.isNotEmpty()) {
            "upi://pay?pa=${Uri.encode(upiId)}&pn=${Uri.encode("Shahid DD7X")}&am=$priceInr&cu=INR&tn=${Uri.encode("DD7X $userId")}"
        } else ""
    }
    val qrBitmap = remember(upiUri) {
        if (upiUri.isNotEmpty()) generateUpiQrBitmap(upiUri) else null
    }

    val paragraphs = remember(priceInr) { buildUnlockParagraphs(priceInr) }
    var selectedLangIdx by remember { mutableIntStateOf(1) }
    var tokenInput by remember { mutableStateOf("") }
    var isVerifying by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .clip(RoundedCornerShape(20.dp))
            .background(colors.lightBrownCard)
            .border(1.dp, colors.lightBrownAccent.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Lifetime Unlock",
                style = PedalTypography.headingSheet,
                color = colors.lightBrownAccent
            )
            Text(
                "₹$priceInr",
                style = PedalTypography.displayBrand,
                color = colors.lightBrownAccent,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(colors.lightBrownField)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        // 7-Language Selector Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            paragraphs.forEachIndexed { index, lang ->
                val selected = selectedLangIdx == index
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (selected) colors.lightBrownAccent else colors.lightBrownField)
                        .clickable { selectedLangIdx = index }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = lang.label,
                        style = PedalTypography.captionMeta,
                        color = if (selected) Color.White else colors.lightBrownText
                    )
                }
            }
        }

        AnimatedContent(
            targetState = paragraphs[selectedLangIdx],
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "langParagraph"
        ) { lang ->
            Text(
                text = lang.paragraph,
                style = PedalTypography.bodyPrimary.copy(lineHeight = 20.sp),
                color = colors.lightBrownText,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(colors.lightBrownField)
                    .padding(12.dp)
            )
        }

        // Line 1: User ID
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(colors.lightBrownField)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("USER ID", style = PedalTypography.knobLegend, color = colors.lightBrownSubtext)
                Text(userId, style = PedalTypography.monoReadout, color = colors.lightBrownText)
            }
            OutlinedButton(
                onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("User ID", userId))
                    Toast.makeText(context, "User ID copied", Toast.LENGTH_SHORT).show()
                }
            ) {
                Text("Copy ID", color = colors.lightBrownAccent)
            }
        }

        // Line 2: Token Line + Unlock Button
        OutlinedTextField(
            value = tokenInput,
            onValueChange = { tokenInput = it.trim(); errorMsg = null },
            label = { Text("Paste Lifetime Token Here") },
            singleLine = true,
            textStyle = PedalTypography.monoReadout,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = colors.lightBrownText,
                unfocusedTextColor = colors.lightBrownText,
                focusedBorderColor = colors.lightBrownAccent,
                unfocusedBorderColor = colors.lightBrownAccent.copy(alpha = 0.45f)
            ),
            modifier = Modifier.fillMaxWidth()
        )

        errorMsg?.let {
            Text(it, style = PedalTypography.captionMeta, color = colors.ledActiveRed)
        }

        Button(
            onClick = {
                scope.launch {
                    isVerifying = true
                    errorMsg = null
                    when (val res = licenseRepo.activate(tokenInput)) {
                        is ActivationApiResult.Activated -> {
                            Toast.makeText(context, "All Features Unlocked for Lifetime!", Toast.LENGTH_LONG).show()
                        }
                        is ActivationApiResult.FriendlyError -> {
                            errorMsg = res.message
                        }
                    }
                    isVerifying = false
                }
            },
            enabled = !isVerifying && tokenInput.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = colors.lightBrownAccent),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(
                if (isVerifying) "Verifying Token..." else "Unlock App for Lifetime",
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Line 3: Bank QR Code (auto-filled Rs. 249 when FOUNDER_UPI_ID secret is set) + UPI Pay + WhatsApp
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(colors.lightBrownField)
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "SCAN QR CODE TO PAY ₹$priceInr",
                style = PedalTypography.knobLegend,
                color = colors.lightBrownSubtext
            )
            if (qrBitmap != null) {
                Image(
                    bitmap = qrBitmap.asImageBitmap(),
                    contentDescription = "UPI ₹$priceInr Payment QR Code",
                    modifier = Modifier
                        .size(190.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .padding(6.dp)
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.payment_qr),
                    contentDescription = "Bank Payment QR Code",
                    modifier = Modifier
                        .size(190.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            }

            if (upiUri.isNotEmpty()) {
                Button(
                    onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(upiUri)))
                        }.onFailure {
                            Toast.makeText(context, "No UPI app found — please scan the QR code.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.lightBrownAccent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Pay ₹$priceInr via UPI App", color = Color.White)
                }
            }

            OutlinedButton(
                onClick = {
                    val p = licenseStatus.userProfile
                    val msg = "Assalamu Alaikum! ₹$priceInr payment done for DD-7X Vocal Delay.\nName: ${p.fullName}\nUsername: ${p.username}\nPhone: ${p.phone}\nUser ID: $userId"
                    val url = "https://wa.me/${BuildConfig.FOUNDER_WHATSAPP_NUMBER}?text=${Uri.encode(msg)}"
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }.onFailure {
                        Toast.makeText(context, "User ID: $userId", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Send Payment Screenshot on WhatsApp", color = colors.lightBrownAccent)
            }
        }
    }
}

@Composable
private fun GateTabPill(
    title: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalPedalColors.current
    Box(
        modifier = modifier
            .height(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) colors.lightBrownAccent else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            style = PedalTypography.captionMeta.copy(fontWeight = FontWeight.SemiBold),
            color = if (active) Color.White else colors.lightBrownSubtext
        )
    }
}
