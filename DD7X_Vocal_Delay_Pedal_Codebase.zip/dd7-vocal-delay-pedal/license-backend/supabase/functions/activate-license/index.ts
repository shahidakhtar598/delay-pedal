import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Content-Type": "application/json",
};

function base64UrlEncode(str: string): string {
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function signEd25519Token(deviceId: string, tier: string, pkcs8Base64: string): Promise<string> {
  const keyBytes = Uint8Array.from(atob(pkcs8Base64), (c) => c.charCodeAt(0));
  const privateKey = await crypto.subtle.importKey("pkcs8", keyBytes, { name: "Ed25519" }, false, ["sign"]);
  const payloadB64 = base64UrlEncode(JSON.stringify({ device_id: deviceId, tier }));
  const sigBuf = await crypto.subtle.sign("Ed25519", privateKey, new TextEncoder().encode(payloadB64));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sigBuf)));
  return `${payloadB64}.${sigB64}`;
}

serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error_code: "METHOD_NOT_ALLOWED" }), { status: 405, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const licenseKey = String(body.license_key ?? "").trim().toUpperCase();
    const deviceFp = String(body.device_fingerprint ?? "").trim().toUpperCase();
    const deviceHash = String(body.device_fingerprint_hash ?? "").trim().toLowerCase();

    if (!/^DD7X-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(licenseKey) || !deviceFp || !deviceHash) {
      return new Response(
        JSON.stringify({ error_code: "INVALID_FORMAT", message: "License key format is invalid." }),
        { status: 400, headers: corsHeaders }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: license } = await supabase
      .from("licenses")
      .select("id, plan_tier, max_devices, status")
      .eq("license_key", licenseKey)
      .maybeSingle();

    if (!license) {
      return new Response(
        JSON.stringify({ error_code: "KEY_NOT_FOUND", message: "Activation key not recognized." }),
        { status: 404, headers: corsHeaders }
      );
    }

    if (license.status === "REVOKED") {
      return new Response(
        JSON.stringify({ error_code: "KEY_REVOKED", message: "This license key has been revoked." }),
        { status: 403, headers: corsHeaders }
      );
    }

    const { data: activeRows } = await supabase
      .from("device_activations")
      .select("id, device_fingerprint_hash, issued_ed25519_token, activated_at")
      .eq("license_id", license.id)
      .eq("is_active", true);

    const existingSameDevice = activeRows?.find((r) => r.device_fingerprint_hash === deviceHash);
    if (existingSameDevice) {
      return new Response(
        JSON.stringify({
          status: "activated",
          plan_tier: license.plan_tier,
          device_fingerprint: deviceFp,
          signed_token: existingSameDevice.issued_ed25519_token,
          activated_at: existingSameDevice.activated_at,
        }),
        { status: 200, headers: corsHeaders }
      );
    }

    if ((activeRows?.length ?? 0) >= license.max_devices) {
      await supabase.from("license_audit_logs").insert({
        license_id: license.id,
        event_type: "ACTIVATION_BLOCKED_LIMIT",
        metadata_json: { blocked_device_fp: deviceFp, device_model: body.device_model ?? null },
      });
      return new Response(
        JSON.stringify({ error_code: "DEVICE_LIMIT_REACHED", message: "This key is already bound to another phone." }),
        { status: 409, headers: corsHeaders }
      );
    }

    const signedToken = await signEd25519Token(
      deviceFp,
      license.plan_tier,
      Deno.env.get("LICENSE_PRIVATE_KEY_ED25519")!
    );

    const nowIso = new Date().toISOString();
    await supabase.from("device_activations").insert({
      license_id: license.id,
      device_fingerprint_hash: deviceHash,
      device_model: body.device_model ?? null,
      android_version: body.android_version ?? null,
      issued_ed25519_token: signedToken,
      is_active: true,
    });

    await supabase.from("licenses").update({ status: "ACTIVE" }).eq("id", license.id);
    await supabase.from("license_audit_logs").insert({
      license_id: license.id,
      event_type: "ACTIVATION_SUCCESS",
      metadata_json: { device_fp: deviceFp, device_model: body.device_model ?? null },
    });

    return new Response(
      JSON.stringify({
        status: "activated",
        plan_tier: license.plan_tier,
        device_fingerprint: deviceFp,
        signed_token: signedToken,
        activated_at: nowIso,
      }),
      { status: 200, headers: corsHeaders }
    );
  } catch (err) {
    console.error("activate-license error:", err);
    return new Response(JSON.stringify({ error_code: "INTERNAL_ERROR" }), { status: 500, headers: corsHeaders });
  }
});
