import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function mintKey(): string {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  const chars = Array.from(bytes, (b) => ALPHABET[b % ALPHABET.length]).join("");
  return `DD7X-${chars.slice(0, 4)}-${chars.slice(4, 8)}`;
}

serve(async (req) => {
  const auth = req.headers.get("Authorization") ?? "";
  if (auth !== `Bearer ${Deno.env.get("ADMIN_API_SECRET")}`) {
    return new Response(JSON.stringify({ error_code: "UNAUTHORIZED" }), { status: 401 });
  }

  const body = await req.json();
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const { data: buyer, error: buyerErr } = await supabase
    .from("buyers")
    .upsert(
      {
        full_name: body.buyer_name,
        whatsapp_phone: body.whatsapp_phone,
        city: body.city ?? null,
        acquisition_source: body.acquisition_source ?? "WhatsApp_Direct",
      },
      { onConflict: "whatsapp_phone" }
    )
    .select("id")
    .single();

  if (buyerErr || !buyer) {
    return new Response(JSON.stringify({ error_code: "BUYER_UPSERT_FAILED" }), { status: 400 });
  }

  const licenseKey = mintKey();
  const { data: lic, error: licErr } = await supabase
    .from("licenses")
    .insert({
      license_key: licenseKey,
      buyer_id: buyer.id,
      payment_ref: body.payment_ref ?? null,
      amount_paid_inr: Number(body.amount_paid_inr ?? 499),
      max_devices: Number(body.max_devices ?? 1),
      status: "UNUSED",
    })
    .select("id, license_key, status")
    .single();

  if (licErr || !lic) {
    return new Response(JSON.stringify({ error_code: "KEY_INSERT_FAILED" }), { status: 500 });
  }

  await supabase.from("license_audit_logs").insert({
    license_id: lic.id,
    event_type: "KEY_MINTED",
    metadata_json: { payment_ref: body.payment_ref ?? null, amount_paid_inr: body.amount_paid_inr ?? 499 },
  });

  return new Response(
    JSON.stringify({ license_key: lic.license_key, buyer_id: buyer.id, status: lic.status }),
    { status: 201, headers: { "Content-Type": "application/json" } }
  );
});
