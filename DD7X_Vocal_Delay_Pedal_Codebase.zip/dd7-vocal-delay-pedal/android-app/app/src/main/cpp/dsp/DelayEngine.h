#pragma once

#include "dsp/DspParams.h"
#include "dsp/DelayLine.h"
#include "dsp/AnalogFilter.h"
#include "dsp/HallReverb.h"
#include "dsp/ModLfo.h"
#include "dsp/PingPongMatrix.h"
#include "dsp/SoftLimiter.h"
#include <cstddef>

namespace dd7 {

class DelayEngine {
public:
    void prepare(double sampleRate);
    void reset() noexcept;

    float processInterleaved(float* stereoBuffer, size_t frameCount, const DspParamSnapshot& params) noexcept;

    bool isLimiting() const noexcept { return limiter_.didLimitRecently(); }
    double sampleRate() const noexcept { return sampleRate_; }

private:
    double sampleRate_ = 48000.0;

    DelayLine delayL_;
    DelayLine delayR_;
    AnalogFilter filterL_;
    AnalogFilter filterR_;
    HallReverb reverb_;
    ModLfo modLfo_;
    SoftLimiter limiter_;

    // Dry vocal leveler (creates clean headroom so repeats never get buried under dry peaks)
    float dryEnv_ = 0.0f;
    float dryAtk_ = 0.99f;
    float dryRel_ = 0.999f;

    float smoothCoeff_ = 0.001f;
    float delaySmoothCoeff_ = 0.0006f;
    float smoothEffectGain_ = 0.0f;
    float smoothFeedback_ = 0.60f;
    float smoothDelaySamples_ = 18240.0f;
    float smoothWetSend_ = 1.0f;
};

} // namespace dd7
