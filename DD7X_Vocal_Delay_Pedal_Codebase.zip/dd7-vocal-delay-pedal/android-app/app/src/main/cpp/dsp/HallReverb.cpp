#include "dsp/HallReverb.h"
#include <algorithm>
#include <cmath>

namespace dd7 {

void HallReverb::prepare(double sampleRate) {
    const double scale = std::max(0.5, sampleRate / 44100.0);
    auto s = [scale](int base) -> size_t {
        return static_cast<size_t>(std::max(16.0, std::round(base * scale)));
    };

    // Classic prime-ratio hall comb lengths (stereo offset for lush width)
    constexpr int kCombBase[4] = { 1116, 1188, 1277, 1356 };
    constexpr int kStereoSpread = 23;
    for (int i = 0; i < 4; ++i) {
        combL_[i].init(s(kCombBase[i]), 0.78f, 0.28f);
        combR_[i].init(s(kCombBase[i] + kStereoSpread), 0.78f, 0.28f);
    }

    apL_[0].init(s(556));
    apL_[1].init(s(441));
    apR_[0].init(s(556 + kStereoSpread));
    apR_[1].init(s(441 + kStereoSpread));
    reset();
}

void HallReverb::reset() noexcept {
    for (int i = 0; i < 4; ++i) {
        combL_[i].clear();
        combR_[i].clear();
    }
    for (int i = 0; i < 2; ++i) {
        apL_[i].clear();
        apR_[i].clear();
    }
}

void HallReverb::processStereo(float inL, float inR, float& outL, float& outR) noexcept {
    const float mono = (inL + inR) * 0.22f;
    float accL = 0.0f;
    float accR = 0.0f;
    for (int i = 0; i < 4; ++i) {
        accL += combL_[i].process(mono);
        accR += combR_[i].process(mono);
    }
    accL = apL_[1].process(apL_[0].process(accL));
    accR = apR_[1].process(apR_[0].process(accR));
    outL = accL * 0.35f;
    outR = accR * 0.35f;
}

} // namespace dd7
