#include "dsp/HallReverb.h"
#include <algorithm>
#include <cmath>

namespace dd7 {

namespace {
constexpr double kPi = 3.14159265358979323846;
}

void HallReverb::prepare(double sampleRate) {
    sampleRate_ = (sampleRate > 8000.0) ? sampleRate : 48000.0;
    const double scale = std::max(0.5, sampleRate_ / 44100.0);
    auto s = [scale](int base) -> size_t {
        return static_cast<size_t>(std::max(16.0, std::round(base * scale)));
    };

    constexpr int kCombBase[4] = { 1116, 1188, 1277, 1356 };
    constexpr int kStereoSpread = 29;
    for (int i = 0; i < 4; ++i) {
        combL_[i].init(s(kCombBase[i]));
        combR_[i].init(s(kCombBase[i] + kStereoSpread));
    }

    apL_[0].init(s(556));
    apL_[1].init(s(441));
    apR_[0].init(s(556 + kStereoSpread));
    apR_[1].init(s(441 + kStereoSpread));

    plusDelayBuf_.assign(static_cast<size_t>(sampleRate_ * 0.220), 0.0f);
    smoothCoeff_ = 1.0f - std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.020));
    reset();
}

void HallReverb::reset() noexcept {
    for (int i = 0; i < 4; ++i) {
        combL_[i].clear();
        combR_[i].clear();
    }
    for (int i = 0; i < 2; ++i) {
        apL_[i].clear();
        apR_[i].clear();
    }
    std::fill(plusDelayBuf_.begin(), plusDelayBuf_.end(), 0.0f);
    plusDelayIdx_ = 0;
    toneLpL_ = toneLpR_ = 0.0f;
    hpPrevInL_ = hpPrevOutL_ = 0.0f;
    hpPrevInR_ = hpPrevOutR_ = 0.0f;
    modPhase_ = 0.0;
    dynEnv_ = 0.0f;
    smoothSend_ = 1.0f;
    smoothLevel_ = 0.42f;
}

void HallReverb::processStereo(
    float inL,
    float inR,
    float& outL,
    float& outR,
    float rvLevel,
    float rvTone,
    float rvTime,
    ReverbMode rvMode,
    bool rvBypassed
) noexcept {
    const float targetSend  = rvBypassed ? 0.0f : 1.0f;
    const float targetLevel = std::pow(std::clamp(rvLevel, 0.0f, 1.0f), 1.15f) * 1.15f;
    smoothSend_  += smoothCoeff_ * (targetSend - smoothSend_);
    smoothLevel_ += smoothCoeff_ * (targetLevel - smoothLevel_);

    // Mode-specific decay & damping character
    const float t = std::clamp(rvTime, 0.0f, 1.0f);
    float baseFb = 0.72f + t * 0.21f; // up to 0.93 long hall tail
    float damp   = 0.35f - std::clamp(rvTone, 0.0f, 1.0f) * 0.25f;

    switch (rvMode) {
        case ReverbMode::ROOM:
            baseFb = 0.58f + t * 0.22f;
            damp   = 0.40f - rvTone * 0.22f;
            break;
        case ReverbMode::HALL:
            baseFb = 0.74f + t * 0.20f;
            damp   = 0.32f - rvTone * 0.22f;
            break;
        case ReverbMode::PLATE:
            baseFb = 0.70f + t * 0.22f;
            damp   = 0.18f - rvTone * 0.12f; // brighter metallic vocal plate
            break;
        case ReverbMode::SPRING:
            baseFb = 0.66f + t * 0.20f;
            damp   = 0.24f;
            break;
        case ReverbMode::MODULATE:
            baseFb = 0.74f + t * 0.20f;
            damp   = 0.26f - rvTone * 0.16f;
            break;
        case ReverbMode::DYNAMIC:
            baseFb = 0.74f + t * 0.20f;
            damp   = 0.30f - rvTone * 0.18f;
            break;
        case ReverbMode::SHIMMER:
            baseFb = 0.76f + t * 0.18f;
            damp   = 0.20f - rvTone * 0.12f;
            break;
        case ReverbMode::PLUS_DELAY:
            baseFb = 0.70f + t * 0.20f;
            damp   = 0.28f - rvTone * 0.18f;
            break;
    }
    baseFb = std::clamp(baseFb, 0.45f, 0.935f);
    damp   = std::clamp(damp, 0.06f, 0.65f);

    const float dryMono = 0.5f * (inL + inR);
    float sendMono = dryMono * smoothSend_ * 0.26f;

    // +DELAY mode: add 220ms rhythmic pre-echo into reverb tank
    if (rvMode == ReverbMode::PLUS_DELAY && !plusDelayBuf_.empty()) {
        const float pdTap = plusDelayBuf_[plusDelayIdx_];
        plusDelayBuf_[plusDelayIdx_] = sendMono + pdTap * 0.36f;
        if (++plusDelayIdx_ >= plusDelayBuf_.size()) plusDelayIdx_ = 0;
        sendMono += pdTap * 0.65f;
    }

    // SHIMMER mode: gentle harmonic octave glow via smooth full-wave harmonic lift
    if (rvMode == ReverbMode::SHIMMER) {
        const float harmonic = (std::fabs(sendMono) - 0.5f * sendMono) * 0.45f;
        sendMono += harmonic;
    }

    // MODULATE mode: subtle chorus pitch/amplitude motion
    float modGainL = 1.0f, modGainR = 1.0f;
    if (rvMode == ReverbMode::MODULATE) {
        modPhase_ += (2.0 * kPi * 0.75) / sampleRate_;
        if (modPhase_ >= 2.0 * kPi) modPhase_ -= 2.0 * kPi;
        const float sMod = static_cast<float>(std::sin(modPhase_)) * 0.12f;
        modGainL = 1.0f + sMod;
        modGainR = 1.0f - sMod;
    }

    // SPRING mode: subtle spring-tank resonant bounce
    const float fbL = (rvMode == ReverbMode::SPRING) ? (baseFb * 0.96f) : baseFb;
    const float fbR = baseFb;

    float accL = 0.0f;
    float accR = 0.0f;
    for (int i = 0; i < 4; ++i) {
        accL += combL_[i].process(sendMono * modGainL, fbL, damp);
        accR += combR_[i].process(sendMono * modGainR, fbR, damp);
    }

    accL = apL_[1].process(apL_[0].process(accL));
    accR = apR_[1].process(apR_[0].process(accR));

    // 1-pole DC/sub-110Hz blocker on reverb output (prevents muddy low-end rumble)
    const float hpL = accL - hpPrevInL_ + 0.985f * hpPrevOutL_;
    hpPrevInL_ = accL; hpPrevOutL_ = hpL;
    const float hpR = accR - hpPrevInR_ + 0.985f * hpPrevOutR_;
    hpPrevInR_ = accR; hpPrevOutR_ = hpR;

    // TONE knob: smooth 1-pole LPF from 1.5 kHz (dark mehfil) to 10 kHz (airy bright)
    const double toneHz = 1500.0 + static_cast<double>(std::clamp(rvTone, 0.0f, 1.0f)) * 8500.0;
    const float toneCoeff = static_cast<float>(1.0 - std::exp(-2.0 * kPi * toneHz / sampleRate_));
    toneLpL_ += toneCoeff * (hpL - toneLpL_);
    toneLpR_ += toneCoeff * (hpR - toneLpR_);

    // DYNAMIC mode: auto-duck reverb while vocal is loud, bloom during pauses!
    float dynMult = 1.0f;
    if (rvMode == ReverbMode::DYNAMIC) {
        const float envIn = std::fabs(dryMono);
        dynEnv_ = (envIn > dynEnv_) ? (0.992f * dynEnv_ + 0.008f * envIn)
                                    : (0.9994f * dynEnv_ + 0.0006f * envIn);
        dynMult = std::clamp(1.0f - dynEnv_ * 1.45f, 0.30f, 1.0f);
    }

    outL = toneLpL_ * 0.42f * smoothLevel_ * dynMult;
    outR = toneLpR_ * 0.42f * smoothLevel_ * dynMult;
}

} // namespace dd7
