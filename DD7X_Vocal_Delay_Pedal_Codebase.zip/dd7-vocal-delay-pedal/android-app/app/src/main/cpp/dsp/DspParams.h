#pragma once

#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace dd7 {

enum class DelayMode : int32_t {
    MS_50    = 0,
    MS_200   = 1,
    MS_800   = 2,
    MS_3200  = 3,
    ANALOG   = 4,
    MODULATE = 5
};

enum class ParamId : int32_t {
    E_LEVEL         = 0,
    F_BACK          = 1,
    D_TIME_MS       = 2,
    MODE            = 3,
    PING_PONG       = 4,
    BYPASS          = 5,
    PING_PONG_WIDTH = 6,
    ANTI_BOOM_CUT   = 7
};

struct DspParamSnapshot {
    float effectLevel   = 0.55f;
    float feedback      = 0.50f;
    float delayTimeMs   = 380.0f;
    DelayMode mode      = DelayMode::ANALOG;
    bool pingPong       = false;
    bool bypassed       = false;
    float pingPongWidth = 0.85f;
    bool antiBoomCut    = true;
};

struct AtomicDspParams {
    std::atomic<float> effectLevel{0.55f};
    std::atomic<float> feedback{0.50f};
    std::atomic<float> delayTimeMs{380.0f};
    std::atomic<int32_t> mode{static_cast<int32_t>(DelayMode::ANALOG)};
    std::atomic<bool> pingPong{false};
    std::atomic<bool> bypassed{false};
    std::atomic<float> pingPongWidth{0.85f};
    std::atomic<bool> antiBoomCut{true};

    void setParam(ParamId id, float value) noexcept {
        if (!std::isfinite(value)) return;
        switch (id) {
            case ParamId::E_LEVEL:
                effectLevel.store(std::clamp(value, 0.0f, 1.0f), std::memory_order_relaxed);
                break;
            case ParamId::F_BACK:
                feedback.store(std::clamp(value, 0.0f, 0.95f), std::memory_order_relaxed);
                break;
            case ParamId::D_TIME_MS:
                delayTimeMs.store(std::clamp(value, 1.0f, 3200.0f), std::memory_order_relaxed);
                break;
            case ParamId::MODE:
                mode.store(std::clamp(static_cast<int32_t>(std::lround(value)), 0, 5), std::memory_order_relaxed);
                break;
            case ParamId::PING_PONG:
                pingPong.store(value >= 0.5f, std::memory_order_relaxed);
                break;
            case ParamId::BYPASS:
                bypassed.store(value >= 0.5f, std::memory_order_relaxed);
                break;
            case ParamId::PING_PONG_WIDTH:
                pingPongWidth.store(std::clamp(value, 0.0f, 1.0f), std::memory_order_relaxed);
                break;
            case ParamId::ANTI_BOOM_CUT:
                antiBoomCut.store(value >= 0.5f, std::memory_order_relaxed);
                break;
        }
    }

    DspParamSnapshot loadSnapshot() const noexcept {
        DspParamSnapshot s;
        s.effectLevel   = effectLevel.load(std::memory_order_relaxed);
        s.feedback      = feedback.load(std::memory_order_relaxed);
        s.delayTimeMs   = delayTimeMs.load(std::memory_order_relaxed);
        s.mode          = static_cast<DelayMode>(mode.load(std::memory_order_relaxed));
        s.pingPong      = pingPong.load(std::memory_order_relaxed);
        s.bypassed      = bypassed.load(std::memory_order_relaxed);
        s.pingPongWidth = pingPongWidth.load(std::memory_order_relaxed);
        s.antiBoomCut   = antiBoomCut.load(std::memory_order_relaxed);
        return s;
    }
};

inline float clampDelayForMode(float requestedMs, DelayMode mode) noexcept {
    switch (mode) {
        case DelayMode::MS_50:    return std::clamp(requestedMs, 1.0f, 50.0f);
        case DelayMode::MS_200:   return std::clamp(requestedMs, 1.0f, 200.0f);
        case DelayMode::MS_800:   return std::clamp(requestedMs, 1.0f, 800.0f);
        case DelayMode::MS_3200:  return std::clamp(requestedMs, 1.0f, 3200.0f);
        case DelayMode::ANALOG:   return std::clamp(requestedMs, 1.0f, 800.0f);
        case DelayMode::MODULATE: return std::clamp(requestedMs, 1.0f, 800.0f);
    }
    return std::clamp(requestedMs, 1.0f, 3200.0f);
}

// Strong BOSS DD-7/DD-8 E.LEVEL taper: ~0.68 (-3.3 dB) at 50%, up to 1.45 at 100%
// Ensures repeats cut cleanly through lead vocals instead of getting buried!
inline float hardwareEffectLevelGain(float normalized) noexcept {
    const float x = std::clamp(normalized, 0.0f, 1.0f);
    return std::pow(x, 1.10f) * 1.45f;
}

// Convex BOSS DD-7/DD-8 F.BACK taper: 50% -> ~0.68 (5-7 distinct repeats), 75% -> ~0.82, max 0.94
inline float hardwareFeedbackGain(float normalized) noexcept {
    const float x = std::clamp(normalized / 0.95f, 0.0f, 1.0f);
    if (x <= 0.001f) return 0.0f;
    return std::clamp(std::pow(x, 0.52f) * 0.94f, 0.0f, 0.94f);
}

} // namespace dd7
