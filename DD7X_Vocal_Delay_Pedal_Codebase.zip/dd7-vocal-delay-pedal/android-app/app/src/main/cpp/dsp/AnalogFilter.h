#pragma once

namespace dd7 {

struct Biquad {
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f;
    float a1 = 0.0f, a2 = 0.0f;
    float z1 = 0.0f, z2 = 0.0f;

    void reset() noexcept { z1 = 0.0f; z2 = 0.0f; }

    inline float process(float x) noexcept {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void setHighPass(double sampleRate, double freqHz, double q = 0.7071);
    void setLowPass(double sampleRate, double freqHz, double q = 0.7071);
    void setNotch(double sampleRate, double freqHz, double q = 2.0);
    void setPeakEq(double sampleRate, double freqHz, double q, double gainDb);
};

class AnalogFilter {
public:
    void prepare(double sampleRate);
    void reset() noexcept;

    // Wet-send vocal clarity conditioning: 210 Hz HPF + 350 Hz Anti-Boom Notch + +3.2 dB @ 2.8 kHz Presence
    float processWetInput(float x, bool antiBoomEnabled) noexcept;

    // Clean feedback-loop conditioning (zero mud, zero crackle, crisp multi-repeat articulation)
    float processFeedback(float x, bool analogMode) noexcept;

private:
    Biquad hpf210_;
    Biquad notch350_;
    Biquad presence2800_;
    Biquad fbHpf90_;

    float digitalLpCoeff_ = 0.65f;
    float analogLpCoeff_  = 0.40f;
    float lpState_        = 0.0f;
};

} // namespace dd7
