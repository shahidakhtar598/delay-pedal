#include "dsp/AnalogFilter.h"
#include <algorithm>
#include <cmath>

namespace dd7 {

namespace {
constexpr double kPi = 3.14159265358979323846;

float onePoleCoeff(double sampleRate, double cutoffHz) {
    return static_cast<float>(1.0 - std::exp(-2.0 * kPi * cutoffHz / sampleRate));
}
} // namespace

void Biquad::setHighPass(double sampleRate, double freqHz, double q) {
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha;
    b0 = static_cast<float>(((1.0 + cosW0) * 0.5) / a0);
    b1 = static_cast<float>((-(1.0 + cosW0)) / a0);
    b2 = static_cast<float>(((1.0 + cosW0) * 0.5) / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha) / a0);
}

void Biquad::setLowPass(double sampleRate, double freqHz, double q) {
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha;
    b0 = static_cast<float>(((1.0 - cosW0) * 0.5) / a0);
    b1 = static_cast<float>((1.0 - cosW0) / a0);
    b2 = static_cast<float>(((1.0 - cosW0) * 0.5) / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha) / a0);
}

void Biquad::setNotch(double sampleRate, double freqHz, double q) {
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha;
    b0 = static_cast<float>(1.0 / a0);
    b1 = static_cast<float>((-2.0 * cosW0) / a0);
    b2 = static_cast<float>(1.0 / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha) / a0);
}

void Biquad::setPeakEq(double sampleRate, double freqHz, double q, double gainDb) {
    const double A = std::pow(10.0, gainDb / 40.0);
    const double w0 = 2.0 * kPi * freqHz / sampleRate;
    const double cosW0 = std::cos(w0);
    const double alpha = std::sin(w0) / (2.0 * q);
    const double a0 = 1.0 + alpha / A;
    b0 = static_cast<float>((1.0 + alpha * A) / a0);
    b1 = static_cast<float>((-2.0 * cosW0) / a0);
    b2 = static_cast<float>((1.0 - alpha * A) / a0);
    a1 = static_cast<float>((-2.0 * cosW0) / a0);
    a2 = static_cast<float>((1.0 - alpha / A) / a0);
}

void AnalogFilter::prepare(double sampleRate) {
    hpf210_.setHighPass(sampleRate, 210.0, 0.7071);
    notch350_.setNotch(sampleRate, 350.0, 2.0);
    presence2800_.setPeakEq(sampleRate, 2800.0, 1.1, 3.2);
    fbHpf90_.setHighPass(sampleRate, 90.0, 0.7071);

    // Crisp vocal articulation across 6+ bounces
    digitalLpCoeff_ = onePoleCoeff(sampleRate, 11000.0);
    analogLpCoeff_  = onePoleCoeff(sampleRate, 4800.0);
    reset();
}

void AnalogFilter::reset() noexcept {
    hpf210_.reset();
    notch350_.reset();
    presence2800_.reset();
    fbHpf90_.reset();
    lpState_ = 0.0f;
}

float AnalogFilter::processWetInput(float x, bool antiBoomEnabled) noexcept {
    if (!std::isfinite(x)) return 0.0f;
    float y = x;
    if (antiBoomEnabled) {
        y = notch350_.process(hpf210_.process(y));
    }
    return presence2800_.process(y);
}

float AnalogFilter::processFeedback(float x, bool analogMode) noexcept {
    if (!std::isfinite(x)) return 0.0f;
    float y = fbHpf90_.process(x);

    const float coeff = analogMode ? analogLpCoeff_ : digitalLpCoeff_;
    lpState_ += coeff * (y - lpState_);
    y = lpState_;

    if (analogMode) {
        y = std::tanh(y * 1.05f) / 1.05f;
    } else if (std::fabs(y) > 0.88f) {
        y = 0.88f + 0.12f * std::tanh((y - (y > 0.0f ? 0.88f : -0.88f)) / 0.12f);
    }
    return y;
}

} // namespace dd7
