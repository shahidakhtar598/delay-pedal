#pragma once

#include <cstddef>
#include <vector>

namespace dd7 {

// Lightweight zero-allocation stereo Schroeder/Freeverb Hall Reverb (+RV).
// Wraps delay repeats in clean studio/mehfil space so echoes float around the vocal.
class HallReverb {
public:
    void prepare(double sampleRate);
    void reset() noexcept;

    void processStereo(float inL, float inR, float& outL, float& outR) noexcept;

private:
    struct Comb {
        std::vector<float> buf;
        size_t idx = 0;
        float filterStore = 0.0f;
        float feedback = 0.80f;
        float damp1 = 0.25f;
        float damp2 = 0.75f;

        void init(size_t len, float fb, float damp) {
            buf.assign(len, 0.0f);
            idx = 0;
            filterStore = 0.0f;
            feedback = fb;
            damp1 = damp;
            damp2 = 1.0f - damp;
        }
        void clear() noexcept {
            std::fill(buf.begin(), buf.end(), 0.0f);
            idx = 0;
            filterStore = 0.0f;
        }
        inline float process(float x) noexcept {
            const float out = buf[idx];
            filterStore = out * damp2 + filterStore * damp1;
            buf[idx] = x + filterStore * feedback;
            if (++idx >= buf.size()) idx = 0;
            return out;
        }
    };

    struct Allpass {
        std::vector<float> buf;
        size_t idx = 0;

        void init(size_t len) {
            buf.assign(len, 0.0f);
            idx = 0;
        }
        void clear() noexcept {
            std::fill(buf.begin(), buf.end(), 0.0f);
            idx = 0;
        }
        inline float process(float x) noexcept {
            const float bufOut = buf[idx];
            const float out = -x + bufOut;
            buf[idx] = x + bufOut * 0.5f;
            if (++idx >= buf.size()) idx = 0;
            return out;
        }
    };

    Comb combL_[4];
    Comb combR_[4];
    Allpass apL_[2];
    Allpass apR_[2];
};

} // namespace dd7
