#pragma once

#include "dsp/DspParams.h"
#include <cstddef>
#include <vector>

namespace dd7 {

// Full 8-Mode RV-6X Stereo Reverb Engine:
// ROOM, HALL, PLATE, SPRING, MODULATE, DYNAMIC (auto-ducking), SHIMMER, +DELAY
class HallReverb {
public:
    void prepare(double sampleRate);
    void reset() noexcept;

    void processStereo(
        float inL,
        float inR,
        float& outL,
        float& outR,
        float rvLevel,
        float rvTone,
        float rvTime,
        ReverbMode rvMode,
        bool rvBypassed
    ) noexcept;

private:
    struct Comb {
        std::vector<float> buf;
        size_t idx = 0;
        float filterStore = 0.0f;

        void init(size_t len) {
            buf.assign(len, 0.0f);
            idx = 0;
            filterStore = 0.0f;
        }
        void clear() noexcept {
            std::fill(buf.begin(), buf.end(), 0.0f);
            idx = 0;
            filterStore = 0.0f;
        }
        inline float process(float x, float fb, float damp) noexcept {
            const float out = buf[idx];
            filterStore = out * (1.0f - damp) + filterStore * damp;
            buf[idx] = x + filterStore * fb;
            if (++idx >= buf.size()) idx = 0;
            return out;
        }
    };

    struct Allpass {
        std::vector<float> buf;
        size_t idx = 0;

        void init(size_t len) {
            buf.assign(len, 0.0f);
            idx = 0;
        }
        void clear() noexcept {
            std::fill(buf.begin(), buf.end(), 0.0f);
            idx = 0;
        }
        inline float process(float x) noexcept {
            const float bufOut = buf[idx];
            const float out = -x + bufOut;
            buf[idx] = x + bufOut * 0.5f;
            if (++idx >= buf.size()) idx = 0;
            return out;
        }
    };

    double sampleRate_ = 48000.0;
    Comb combL_[4];
    Comb combR_[4];
    Allpass apL_[2];
    Allpass apR_[2];

    // Pre-delay / +DELAY short stereo buffer (~220ms)
    std::vector<float> plusDelayBuf_;
    size_t plusDelayIdx_ = 0;

    // Tone & DC-block states
    float toneLpL_ = 0.0f;
    float toneLpR_ = 0.0f;
    float hpPrevInL_ = 0.0f, hpPrevOutL_ = 0.0f;
    float hpPrevInR_ = 0.0f, hpPrevOutR_ = 0.0f;

    // Modulation LFO + Dynamic envelope + Shimmer phase
    double modPhase_ = 0.0;
    float dynEnv_ = 0.0f;
    float smoothSend_ = 1.0f;
    float smoothLevel_ = 0.42f;
    float smoothCoeff_ = 0.001f;
};

} // namespace dd7
