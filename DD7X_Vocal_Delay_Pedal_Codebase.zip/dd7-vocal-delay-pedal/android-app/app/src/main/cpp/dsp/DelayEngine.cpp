#include "dsp/DelayEngine.h"
#include <algorithm>
#include <cmath>

namespace dd7 {

void DelayEngine::prepare(double sampleRate) {
    sampleRate_ = (sampleRate > 8000.0) ? sampleRate : 48000.0;
    delayL_.prepare(sampleRate_, 3300.0f);
    delayR_.prepare(sampleRate_, 3300.0f);
    filterL_.prepare(sampleRate_);
    filterR_.prepare(sampleRate_);
    reverb_.prepare(sampleRate_);
    modLfo_.prepare(sampleRate_, 0.85f, 2.2f);
    limiter_.prepare(sampleRate_);

    dryAtk_ = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.008));
    dryRel_ = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.120));

    smoothCoeff_      = 1.0f - std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.020));
    delaySmoothCoeff_ = 1.0f - std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.035));
    reset();
}

void DelayEngine::reset() noexcept {
    delayL_.reset();
    delayR_.reset();
    filterL_.reset();
    filterR_.reset();
    reverb_.reset();
    modLfo_.reset();
    limiter_.reset();
    dryEnv_ = 0.0f;
    smoothEffectGain_ = 0.0f;
    smoothFeedback_ = 0.60f;
    smoothDelaySamples_ = static_cast<float>(sampleRate_ * 0.380);
    smoothWetSend_ = 1.0f;
}

float DelayEngine::processInterleaved(
    float* stereoBuffer,
    size_t frameCount,
    const DspParamSnapshot& params
) noexcept {
    if (!stereoBuffer || frameCount == 0) return 0.0f;

    const float targetEffectGain = hardwareEffectLevelGain(params.effectLevel);
    const float targetFeedback   = hardwareFeedbackGain(params.feedback);
    const float clampedMs        = clampDelayForMode(params.delayTimeMs, params.mode);
    const float targetDelaySamp  = static_cast<float>(sampleRate_ * (clampedMs / 1000.0));
    const float targetWetSend    = params.bypassed ? 0.0f : 1.0f;

    const bool isAnalog   = (params.mode == DelayMode::ANALOG);
    const bool isModulate = (params.mode == DelayMode::MODULATE);

    const float stereoOffsetSamp = params.pingPong ? 0.0f : static_cast<float>(sampleRate_ * 0.014);

    float blockPeak = 0.0f;

    for (size_t i = 0; i < frameCount; ++i) {
        smoothEffectGain_   += smoothCoeff_      * (targetEffectGain - smoothEffectGain_);
        smoothFeedback_     += smoothCoeff_      * (targetFeedback - smoothFeedback_);
        smoothDelaySamples_ += delaySmoothCoeff_ * (targetDelaySamp - smoothDelaySamples_);
        smoothWetSend_      += smoothCoeff_      * (targetWetSend - smoothWetSend_);

        const float rawL = stereoBuffer[i * 2];
        const float rawR = stereoBuffer[i * 2 + 1];
        const float inL  = std::isfinite(rawL) ? rawL : 0.0f;
        const float inR  = std::isfinite(rawR) ? rawR : 0.0f;

        // 0. Smooth Dry Vocal Headroom Leveler
        const float inPeak = std::max(std::fabs(inL), std::fabs(inR));
        dryEnv_ = (inPeak > dryEnv_)
            ? (dryAtk_ * dryEnv_ + (1.0f - dryAtk_) * inPeak)
            : (dryRel_ * dryEnv_ + (1.0f - dryRel_) * inPeak);
        float compGain = 1.0f;
        if (dryEnv_ > 0.40f) {
            compGain = std::pow(dryEnv_ / 0.40f, -0.55f);
        }
        const float dryL = inL * compGain * 0.78f;
        const float dryR = inR * compGain * 0.78f;

        // --- PEDAL 1: DD-7X DELAY ---
        const float sendL = filterL_.processWetInput(inL * compGain * smoothWetSend_, params.antiBoomCut);
        const float sendR = filterR_.processWetInput(inR * compGain * smoothWetSend_, params.antiBoomCut);

        const float lfoOffset  = isModulate ? modLfo_.nextOffsetSamples() : 0.0f;
        const float readDelayL = std::max(1.0f, smoothDelaySamples_ + lfoOffset);
        const float readDelayR = std::max(1.0f, smoothDelaySamples_ + stereoOffsetSamp - lfoOffset * 0.75f);

        const float tapL = delayL_.readHermite(readDelayL);
        const float tapR = delayR_.readHermite(readDelayR);

        const float fbL = filterL_.processFeedback(tapL, isAnalog);
        const float fbR = filterR_.processFeedback(tapR, isAnalog);

        const auto nextIn = PingPongMatrix::computeDelayInputs(
            sendL, sendR, fbL, fbR, smoothFeedback_, params.pingPong
        );

        delayL_.push(std::tanh(nextIn.left * 0.85f) / 0.85f);
        delayR_.push(std::tanh(nextIn.right * 0.85f) / 0.85f);

        const auto wetStereo = PingPongMatrix::applyWidth(tapL, tapR, params.pingPong ? params.pingPongWidth : 1.0f);
        const float postDelayL = dryL + wetStereo.left  * smoothEffectGain_;
        const float postDelayR = dryR + wetStereo.right * smoothEffectGain_;

        // --- PEDAL 2: RV-6X REVERB (Independent 8-Mode Studio Reverb Pedal) ---
        float revL = 0.0f, revR = 0.0f;
        reverb_.processStereo(
            postDelayL, postDelayR,
            revL, revR,
            params.rvLevel, params.rvTone, params.rvTime,
            params.rvMode, params.rvBypassed
        );

        float outL = postDelayL + revL;
        float outR = postDelayR + revR;
        limiter_.processStereo(outL, outR);

        stereoBuffer[i * 2]     = outL;
        stereoBuffer[i * 2 + 1] = outR;

        const float framePeak = std::max(std::fabs(outL), std::fabs(outR));
        if (framePeak > blockPeak) blockPeak = framePeak;
    }

    return blockPeak;
}

} // namespace dd7
