package com.naatdelay.dd7.ui.presets

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.data.local.entity.PresetEntity
import com.naatdelay.dd7.data.repository.SavePresetResult
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PresetDrawer(
    presets: List<PresetEntity>,
    activePresetId: String?,
    onSelect: (PresetEntity) -> Unit,
    onDelete: (String) -> Unit,
    onSaveNew: suspend (String, Boolean) -> SavePresetResult,
    onDismiss: () -> Unit
) {
    val colors = LocalPedalColors.current
    val scope = rememberCoroutineScope()
    var selectedPreset by remember(activePresetId, presets) {
        mutableStateOf(presets.firstOrNull { it.id == activePresetId } ?: presets.firstOrNull())
    }
    var newName by remember { mutableStateOf("") }
    var feedbackMsg by remember { mutableStateOf<String?>(null) }
    var pendingOverwrite by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = colors.bronzeSheetBg,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, colors.bronzeBorderGold.copy(alpha = 0.7f), RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF332419), Color(0xFF1F160F)))
                )
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Naat Vocal Presets",
                style = PedalTypography.headingSheet,
                color = colors.bronzeTextPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            LazyColumn(
                modifier = Modifier.fillMaxWidth().height(250.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(presets, key = { it.id }) { p ->
                    val isSelected = selectedPreset?.id == p.id
                    val rowBg = if (isSelected) {
                        Brush.horizontalGradient(listOf(Color(0xFF7B5535), Color(0xFF533720)))
                    } else {
                        Brush.horizontalGradient(listOf(Color(0xFF2B1F16), Color(0xFF241912)))
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(rowBg)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = colors.bronzeBorderGold.copy(alpha = if (isSelected) 0.95f else 0.35f),
                                shape = RoundedCornerShape(24.dp)
                            )
                            .clickable { selectedPreset = p }
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Radio circle
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, colors.bronzeBorderGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(colors.bronzeTextPrimary)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.name, style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                            Text(
                                text = "${p.delayMode} · ${p.delayTimeMs.toInt()}ms · FB ${(p.feedback * 100).toInt()}%",
                                style = PedalTypography.captionMeta,
                                color = colors.bronzeTextMuted
                            )
                        }

                        if (!p.isFactory) {
                            IconButton(onClick = { onDelete(p.id) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.ledActiveRed)
                            }
                        }
                    }
                }
            }

            // Compact Save Custom Preset Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newName,
                    onValueChange = {
                        if (it.length <= 28) {
                            newName = it
                            pendingOverwrite = false
                            feedbackMsg = null
                        }
                    },
                    placeholder = { Text("Save custom preset...", color = colors.bronzeTextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = colors.bronzeTextPrimary,
                        unfocusedTextColor = colors.bronzeTextPrimary,
                        focusedBorderColor = colors.bronzeBorderGold,
                        unfocusedBorderColor = colors.bronzeBorderGold.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        scope.launch {
                            when (onSaveNew(newName, pendingOverwrite)) {
                                is SavePresetResult.Saved -> { newName = ""; pendingOverwrite = false; feedbackMsg = "Saved!" }
                                SavePresetResult.BlankNameError -> feedbackMsg = "Enter a name."
                                SavePresetResult.FactoryNameConflict -> feedbackMsg = "Reserved factory name."
                                is SavePresetResult.DuplicateCustomExists -> { pendingOverwrite = true; feedbackMsg = "Tap Save again to overwrite." }
                                SavePresetResult.TrialLimitReached -> feedbackMsg = "Pro required."
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.bronzePillActive)
                ) {
                    Text(if (pendingOverwrite) "Overwrite" else "Save", color = colors.bronzeTextPrimary)
                }
            }

            feedbackMsg?.let {
                Text(it, style = PedalTypography.captionMeta, color = colors.bronzeBorderGold)
            }

            // Bottom APPLY button matching mockup
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF7B5535), Color(0xFF5A3B22))))
                    .border(1.dp, colors.bronzeBorderGold, RoundedCornerShape(14.dp))
                    .clickable { selectedPreset?.let(onSelect) },
                contentAlignment = Alignment.Center
            ) {
                Text("APPLY", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
            }
        }
    }
}
