package com.naatdelay.dd7.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography

@Composable
fun WaveformScrubber(
    trackName: String,
    peaks: List<Float>,
    positionMs: Long,
    durationMs: Long,
    isPlaying: Boolean,
    isLooping: Boolean,
    isLimiting: Boolean,
    onTogglePlay: () -> Unit,
    onToggleLoop: () -> Unit,
    onSeekMs: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalPedalColors.current
    val progress = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF2E333C), Color(0xFF21252C)))
            )
            .border(1.dp, Color(0xFF3E4552), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Sleek circular matte play/pause button matching mockup
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF3B4350))
                    .border(1.dp, Color(0xFF556072), CircleShape)
                    .clickable(onClick = onTogglePlay),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color(0xFFE6EEF8),
                    modifier = Modifier.size(20.dp)
                )
            }

            Canvas(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .pointerInput(durationMs) {
                        detectTapGestures { offset ->
                            if (durationMs > 0L && size.width > 0) {
                                val pct = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                onSeekMs((durationMs * pct).toLong())
                            }
                        }
                    }
            ) {
                val barList = if (peaks.isNotEmpty()) peaks else List(56) { i ->
                    val wave = kotlin.math.abs(kotlin.math.sin(i * 0.42f)) * 0.65f + 0.18f
                    wave
                }
                val step = size.width / barList.size.toFloat()
                val midY = size.height / 2f
                val strokeW = (step * 0.56f).coerceAtLeast(2f)

                barList.forEachIndexed { idx, amp ->
                    val x = idx * step + step / 2f
                    val halfH = (amp.coerceIn(0.10f, 1f) * midY * 0.92f)
                    val played = (idx.toFloat() / barList.size.toFloat()) <= progress
                    drawLine(
                        color = if (played) Color(0xFF47C8E8) else Color(0xFF5A6372),
                        start = Offset(x, midY - halfH),
                        end = Offset(x, midY + halfH),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                }
            }

            // Compact loop toggle icon
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(if (isLooping) Color(0xFF1F4C63) else Color.Transparent)
                    .clickable(onClick = onToggleLoop),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Repeat,
                    contentDescription = "Loop",
                    tint = if (isLooping) Color(0xFF47C8E8) else Color(0xFF8C96A6),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = trackName,
                style = PedalTypography.captionMeta.copy(fontSize = 10.sp),
                color = Color(0xFF9AA5B4),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${formatTimeMs(positionMs)} / ${formatTimeMs(durationMs)}",
                style = PedalTypography.monoReadout.copy(fontSize = 11.sp),
                color = if (isLimiting) colors.statusWarning else Color(0xFFD0D8E2)
            )
        }
    }
}

private fun formatTimeMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%02d:%02d".format(min, sec)
}
