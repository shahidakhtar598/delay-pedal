package com.naatdelay.dd7.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.naatdelay.dd7.data.local.dao.ExportDao
import com.naatdelay.dd7.data.local.dao.LicenseDao
import com.naatdelay.dd7.data.local.dao.PresetDao
import com.naatdelay.dd7.data.local.dao.ProjectDao
import com.naatdelay.dd7.data.local.entity.AudioProjectEntity
import com.naatdelay.dd7.data.local.entity.DeviceLicenseEntity
import com.naatdelay.dd7.data.local.entity.ExportHistoryEntity
import com.naatdelay.dd7.data.local.entity.PresetEntity

@Database(
    entities = [
        PresetEntity::class,
        AudioProjectEntity::class,
        ExportHistoryEntity::class,
        DeviceLicenseEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun presetDao(): PresetDao
    abstract fun projectDao(): ProjectDao
    abstract fun exportDao(): ExportDao
    abstract fun licenseDao(): LicenseDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE presets ADD COLUMN rv_mode TEXT NOT NULL DEFAULT 'HALL'")
                db.execSQL("ALTER TABLE presets ADD COLUMN rv_level REAL NOT NULL DEFAULT 0.42")
                db.execSQL("ALTER TABLE presets ADD COLUMN rv_tone REAL NOT NULL DEFAULT 0.58")
                db.execSQL("ALTER TABLE presets ADD COLUMN rv_time REAL NOT NULL DEFAULT 0.52")
                db.execSQL("ALTER TABLE presets ADD COLUMN rv_bypassed INTEGER NOT NULL DEFAULT 0")
            }
        }

        // Founder Factory Presets (DD-7X Delay + RV-6X Reverb combined) — auto-synced for ALL users!
        val FACTORY_PRESETS: List<PresetEntity> = listOf(
            PresetEntity("preset-factory-01", "Default Vocal", true, "ANALOG", 0.52f, 0.45f, 380f, false, 0.85f, true, "HALL", 0.42f, 0.58f, 0.52f, false, 1L, 1L),
            PresetEntity("preset-yt-01", "Sair e Gulshan Kon Dekhe", true, "MS_800", 0.58f, 0.52f, 410f, false, 0.85f, true, "HALL", 0.44f, 0.55f, 0.58f, false, 2L, 2L),
            PresetEntity("preset-yt-02", "Jo Madina Ham Bhi Jaate", true, "ANALOG", 0.60f, 0.56f, 450f, true, 0.88f, true, "HALL", 0.48f, 0.50f, 0.64f, false, 3L, 3L),
            PresetEntity("preset-yt-03", "Pul Se Utaro Rah Guzar", true, "MS_800", 0.56f, 0.50f, 420f, false, 0.85f, true, "HALL", 0.42f, 0.58f, 0.54f, false, 4L, 4L),
            PresetEntity("preset-yt-04", "Sunte Hai Ke Mehshar Me", true, "MS_800", 0.62f, 0.56f, 365f, false, 0.85f, true, "HALL", 0.45f, 0.60f, 0.55f, false, 5L, 5L),
            PresetEntity("preset-yt-05", "Tasweer e Muhammad Hai", true, "MS_800", 0.54f, 0.46f, 320f, false, 0.82f, true, "PLATE", 0.38f, 0.64f, 0.46f, false, 6L, 6L),
            PresetEntity("preset-yt-06", "Jabee'n Meri Ho Sange Dar", true, "ANALOG", 0.62f, 0.58f, 460f, true, 0.90f, true, "HALL", 0.50f, 0.52f, 0.66f, false, 7L, 7L),
            PresetEntity("preset-yt-07", "Sartaba Qadam Hai", true, "MS_800", 0.56f, 0.48f, 340f, false, 0.84f, true, "PLATE", 0.40f, 0.62f, 0.50f, false, 8L, 8L),
            PresetEntity("preset-yt-08", "Koi Gul Baqi Rahega", true, "ANALOG", 0.60f, 0.55f, 430f, true, 0.88f, true, "HALL", 0.48f, 0.54f, 0.62f, false, 9L, 9L),
            PresetEntity("preset-yt-09", "Unki Mahek Nay Dil Ke", true, "MS_800", 0.58f, 0.52f, 375f, false, 0.85f, true, "HALL", 0.44f, 0.60f, 0.52f, false, 10L, 10L),
            PresetEntity("preset-yt-10", "Pahuchu Dare Sarkar Pe", true, "MODULATE", 0.55f, 0.54f, 440f, true, 0.86f, true, "DYNAMIC", 0.46f, 0.52f, 0.60f, false, 11L, 11L),
            PresetEntity("preset-yt-11", "Warafana Laka Zikrak", true, "MS_200", 0.50f, 0.42f, 195f, false, 0.80f, true, "ROOM", 0.36f, 0.65f, 0.42f, false, 12L, 12L)
        )

        private fun insertFactoryPresets(db: SupportSQLiteDatabase) {
            FACTORY_PRESETS.forEach { p ->
                db.execSQL(
                    """INSERT OR IGNORE INTO presets
                       (id, name, is_factory, delay_mode, effect_level, feedback, delay_time_ms,
                        is_ping_pong, ping_pong_width, anti_boom_cut,
                        rv_mode, rv_level, rv_tone, rv_time, rv_bypassed,
                        created_at, updated_at)
                       VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    arrayOf(
                        p.id, p.name, p.delayMode, p.effectLevel, p.feedback, p.delayTimeMs,
                        if (p.isPingPong) 1 else 0, p.pingPongWidth, if (p.antiBoomCut) 1 else 0,
                        p.rvMode, p.rvLevel, p.rvTone, p.rvTime, if (p.rvBypassed) 1 else 0,
                        p.createdAt, p.updatedAt
                    )
                )
            }
        }

        fun seedCallback(): Callback = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                insertFactoryPresets(db)
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                insertFactoryPresets(db)
            }
        }
    }
}
