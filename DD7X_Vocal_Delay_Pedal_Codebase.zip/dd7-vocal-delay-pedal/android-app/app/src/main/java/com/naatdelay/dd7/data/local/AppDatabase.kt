package com.naatdelay.dd7.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.naatdelay.dd7.data.local.dao.ExportDao
import com.naatdelay.dd7.data.local.dao.LicenseDao
import com.naatdelay.dd7.data.local.dao.PresetDao
import com.naatdelay.dd7.data.local.dao.ProjectDao
import com.naatdelay.dd7.data.local.entity.AudioProjectEntity
import com.naatdelay.dd7.data.local.entity.DeviceLicenseEntity
import com.naatdelay.dd7.data.local.entity.ExportHistoryEntity
import com.naatdelay.dd7.data.local.entity.PresetEntity

@Database(
    entities = [
        PresetEntity::class,
        AudioProjectEntity::class,
        ExportHistoryEntity::class,
        DeviceLicenseEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun presetDao(): PresetDao
    abstract fun projectDao(): ProjectDao
    abstract fun exportDao(): ExportDao
    abstract fun licenseDao(): LicenseDao

    companion object {
        // Add any new founder presets here — they automatically appear for ALL new and existing users!
        val FACTORY_PRESETS: List<PresetEntity> = listOf(
            PresetEntity("preset-factory-01", "Default Vocal", true, "ANALOG", 0.52f, 0.45f, 380f, false, 0.85f, true, 1L, 1L),
            PresetEntity("preset-factory-02", "Sabir Raza Mehfil", true, "MS_800", 0.62f, 0.56f, 365f, false, 0.85f, true, 2L, 2L),
            PresetEntity("preset-factory-03", "Madina Eco (Echo)", true, "MS_800", 0.58f, 0.50f, 440f, true, 0.90f, true, 3L, 3L),
            PresetEntity("preset-factory-04", "Sana Khawan High", true, "MS_200", 0.46f, 0.36f, 190f, false, 0.80f, true, 4L, 4L),
            PresetEntity("preset-factory-05", "Masjid Echo (Deep)", true, "ANALOG", 0.64f, 0.62f, 560f, true, 0.88f, true, 5L, 5L),
            PresetEntity("preset-factory-06", "Chorus Shimmer Hamd", true, "MODULATE", 0.52f, 0.46f, 390f, true, 0.85f, true, 6L, 6L),
            PresetEntity("preset-factory-07", "Short Slapback Recite", true, "MS_50", 0.44f, 0.25f, 48f, false, 0.70f, true, 7L, 7L),
            PresetEntity("preset-factory-08", "Deep Jalsa Long", true, "MS_3200", 0.56f, 0.55f, 920f, true, 0.92f, true, 8L, 8L)
        )

        private fun insertFactoryPresets(db: SupportSQLiteDatabase) {
            FACTORY_PRESETS.forEach { p ->
                db.execSQL(
                    """INSERT OR IGNORE INTO presets
                       (id, name, is_factory, delay_mode, effect_level, feedback, delay_time_ms,
                        is_ping_pong, ping_pong_width, anti_boom_cut, created_at, updated_at)
                       VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    arrayOf(
                        p.id, p.name, p.delayMode, p.effectLevel, p.feedback, p.delayTimeMs,
                        if (p.isPingPong) 1 else 0, p.pingPongWidth, if (p.antiBoomCut) 1 else 0,
                        p.createdAt, p.updatedAt
                    )
                )
            }
        }

        fun seedCallback(): Callback = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                insertFactoryPresets(db)
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                insertFactoryPresets(db)
            }
        }
    }
}
