package com.naatdelay.dd7.ui.pedal

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.naatdelay.dd7.ui.components.PingPongToggle
import com.naatdelay.dd7.ui.components.RotaryKnob
import com.naatdelay.dd7.ui.components.StompSwitch
import com.naatdelay.dd7.ui.components.WaveformScrubber
import com.naatdelay.dd7.ui.export.ExportSheet
import com.naatdelay.dd7.ui.presets.PresetDrawer
import com.naatdelay.dd7.ui.settings.SettingsSheet
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PedalScreen(viewModel: PedalViewModel) {
    val state by viewModel.uiState.collectAsState()
    val presets by viewModel.presets.collectAsState()
    val license by viewModel.licenseStatus.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    val colors = LocalPedalColors.current
    val context = LocalContext.current
    val screenHeightDp = LocalConfiguration.current.screenHeightDp
    val upperKnobSize = if (screenHeightDp < 700) 52.dp else 62.dp
    val modeKnobSize = if (screenHeightDp < 700) 60.dp else 70.dp
    val stompHeight = if (screenHeightDp < 700) 114.dp else 148.dp

    var showPresets by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val openAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.importAudio(uri)
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "ledPulse")
    val ledPulse by pulseTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ledAlpha"
    )

    val chassisBg by animateColorAsState(colors.bgChassis, label = "chassisBg")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(chassisBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // 1. Brushed Warm Bronze-Brown Top System Tab Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF4B3726), Color(0xFF2B1F16), Color(0xFF1A130E))
                    )
                )
                .padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BronzeSystemPill("Import", false, false, Modifier.weight(1f)) {
                openAudioLauncher.launch(
                    arrayOf("audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac", "audio/ogg", "audio/opus")
                )
            }
            BronzeSystemPill("Presets", showPresets, false, Modifier.weight(1f)) { showPresets = true }
            BronzeSystemPill("Export", showExport, false, Modifier.weight(1f)) { showExport = true }
            BronzeSystemPill("Theme", state.darkStudioTheme, false, Modifier.weight(1f)) { viewModel.toggleTheme() }
            BronzeSystemPill("Setting", showSettings, license.isProActivated, Modifier.weight(1f)) { showSettings = true }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            androidx.compose.animation.AnimatedVisibility(visible = state.statusBanner != null, enter = fadeIn(), exit = fadeOut()) {
                state.statusBanner?.let { msg ->
                    Text(
                        text = msg,
                        style = PedalTypography.captionMeta,
                        color = colors.statusWarning,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.statusWarning.copy(alpha = 0.14f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            // 2. Sleek Dark Waveform & Transport Bar
            WaveformScrubber(
                trackName = if (state.isImporting) "Decoding audio..." else state.trackName,
                peaks = state.waveformPeaks,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                isPlaying = state.isPlaying,
                isLooping = state.isLooping,
                isLimiting = state.isLimiting,
                onTogglePlay = viewModel::togglePlayback,
                onToggleLoop = viewModel::toggleLoop,
                onSeekMs = viewModel::seekTo
            )

            // 3. Dual-Pedal Switcher Bar: [ ● DD-7X DELAY ] [ ● RV-6X REVERB ]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF1F1711))
                    .border(1.dp, colors.bronzeBorderGold.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PedalSwitcherTab(
                    label = "DD-7X DELAY",
                    isSelected = state.activePedalIndex == 0,
                    isEffectEngaged = !state.isBypassed,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectPedal(0) }
                )
                PedalSwitcherTab(
                    label = "RV-6X REVERB",
                    isSelected = state.activePedalIndex == 1,
                    isEffectEngaged = !state.rvBypassed,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectPedal(1) }
                )
            }

            // 4. Animated Dual-Pedal Chassis Area
            AnimatedContent(
                targetState = state.activePedalIndex,
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally { it * dir } + fadeIn()) togetherWith
                        (slideOutHorizontally { -it * dir } + fadeOut())
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                label = "dualPedalSwitch"
            ) { pedalIdx ->
                if (pedalIdx == 0) {
                    DD7XDelayPedalCard(
                        state = state,
                        ledPulse = ledPulse,
                        upperKnobSize = upperKnobSize,
                        modeKnobSize = modeKnobSize,
                        stompHeight = stompHeight,
                        viewModel = viewModel
                    )
                } else {
                    RV6XReverbPedalCard(
                        state = state,
                        ledPulse = ledPulse,
                        upperKnobSize = upperKnobSize,
                        modeKnobSize = modeKnobSize,
                        stompHeight = stompHeight,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (showPresets) {
        PresetDrawer(
            presets = presets,
            activePresetId = state.activePresetId,
            onSelect = {
                viewModel.applyPreset(it)
                showPresets = false
            },
            onDelete = viewModel::deleteCustomPreset,
            onSaveNew = { name, overwrite -> viewModel.saveCustomPreset(name, overwrite) },
            onDismiss = { showPresets = false }
        )
    }

    if (showExport) {
        ExportSheet(
            defaultFileName = state.trackName.substringBeforeLast('.').ifBlank { "Naat_DD7X" } + "_DD7X",
            hasAudioLoaded = state.cachedPcmPath != null,
            isProActivated = license.isProActivated,
            exportState = exportState,
            onStartExport = { name, fmt -> viewModel.startExport(context, name, fmt) },
            onCancelExport = { viewModel.cancelExport(context) },
            onOpenActivation = {
                showExport = false
                showSettings = true
            },
            onDismiss = { showExport = false }
        )
    }

    if (showSettings) {
        SettingsSheet(
            licenseStatus = license,
            antiBoomCut = state.antiBoomCut,
            pingPongWidth = state.pingPongWidth,
            onAntiBoomChange = viewModel::setAntiBoomCut,
            onPingPongWidthChange = viewModel::setPingPongWidth,
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
private fun DD7XDelayPedalCard(
    state: PedalUiState,
    ledPulse: Float,
    upperKnobSize: Dp,
    modeKnobSize: Dp,
    stompHeight: Dp,
    viewModel: PedalViewModel
) {
    val colors = LocalPedalColors.current
    var beatLedGreen by remember { mutableStateOf(false) }

    // Authentic BOSS DD-7 beat-synced Red <-> Green Tempo LED
    LaunchedEffect(state.delayTimeMs, state.isBypassed) {
        if (state.isBypassed) {
            beatLedGreen = false
            return@LaunchedEffect
        }
        val beatIntervalMs = state.delayTimeMs.toLong().coerceIn(80L, 1600L)
        while (true) {
            delay(beatIntervalMs)
            beatLedGreen = !beatLedGreen
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(colors.pedalBodyTop, colors.pedalBodyBottom)))
            .border(2.dp, if (state.darkStudioTheme) Color(0xFF424954) else Color(0xFFA8AFBA), RoundedCornerShape(18.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Arched Cobalt Control Plate
        Box(modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp)) {
            Canvas(modifier = Modifier.matchParentSize()) {
                drawArchedPlate(
                    brush = Brush.verticalGradient(listOf(Color(0xFF1E67D6), colors.pedalCobaltStripe, Color(0xFF103F92))),
                    arcColor = Color.White.copy(alpha = 0.5f)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(start = 26.dp, top = 7.dp)
            ) {
                val ledColor = when {
                    state.isTapTempoMode -> colors.ledTempoGreen
                    !state.isBypassed -> colors.ledActiveRed
                    else -> Color(0xFF3A414A)
                }
                Box(
                    modifier = Modifier
                        .size(11.dp)
                        .alpha(if (!state.isBypassed || state.isTapTempoMode) ledPulse else 1f)
                        .clip(CircleShape)
                        .background(ledColor)
                        .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape)
                )
                Text("CHECK", style = PedalTypography.knobLegend, color = Color.White)
            }

            // Top-Right Beat-Synced Red <-> Green Tempo LED (exact marked spot left of top-right screw)
            val tempoLedColor by animateColorAsState(
                targetValue = when {
                    state.isBypassed -> Color(0xFF3A414A)
                    beatLedGreen -> Color(0xFF00E676)
                    else -> Color(0xFFFF3B30)
                },
                label = "beatTempoLed"
            )
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = 26.dp, top = 6.dp)
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(
                        if (!state.isBypassed) tempoLedColor.copy(alpha = 0.32f) else Color.Transparent
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(11.dp)
                        .clip(CircleShape)
                        .background(tempoLedColor)
                        .border(1.dp, Color.White.copy(alpha = 0.75f), CircleShape)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 12.dp, start = 6.dp, end = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RotaryKnob(
                    label = "E.LEVEL",
                    value = state.effectLevel,
                    defaultValue = 0.55f,
                    readoutText = "${(state.effectLevel * 100).toInt()}%",
                    onValueChange = viewModel::setEffectLevel,
                    knobSize = upperKnobSize,
                    arcColor = Color(0xFF47E5FF),
                    modifier = Modifier.offset(y = 8.dp)
                )
                RotaryKnob(
                    label = "F.BACK",
                    value = state.feedback / 0.95f,
                    defaultValue = 0.50f / 0.95f,
                    readoutText = "${(state.feedback * 100).toInt()}%",
                    onValueChange = { viewModel.setFeedback(it * 0.95f) },
                    knobSize = upperKnobSize,
                    arcColor = Color(0xFF47E5FF),
                    modifier = Modifier.offset(y = (-7).dp)
                )
                val timeNorm = ((state.delayTimeMs - 1f) / (state.mode.maxMs - 1f)).coerceIn(0f, 1f)
                RotaryKnob(
                    label = "D.TIME",
                    value = timeNorm,
                    defaultValue = (380f / state.mode.maxMs).coerceIn(0f, 1f),
                    readoutText = "${state.delayTimeMs.toInt()} ms",
                    onValueChange = viewModel::setDelayTimeNormalized,
                    knobSize = upperKnobSize,
                    arcColor = Color(0xFF47E5FF),
                    modifier = Modifier.offset(y = 8.dp)
                )
            }
        }

        // Center MODE Dial + Ping-Pong Switch
        Box(modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
            val labelColor = if (state.darkStudioTheme) Color(0xFFE6ECF5) else Color(0xFF1A1E24)
            val activeAccent = if (state.darkStudioTheme) Color(0xFF47E5FF) else colors.pedalCobaltStripe

            Canvas(modifier = Modifier.matchParentSize()) {
                drawScrewHead(Offset(10.dp.toPx(), size.height - 10.dp.toPx()), 6.dp.toPx())
                drawScrewHead(Offset(size.width - 10.dp.toPx(), size.height - 10.dp.toPx()), 6.dp.toPx())
            }

            Box(modifier = Modifier.align(Alignment.Center).offset(y = (-4).dp), contentAlignment = Alignment.Center) {
                val modes = UiDelayMode.entries
                val anglesDeg = listOf(160f, 196f, 232f, 270f, 308f, 344f)
                modes.forEachIndexed { idx, m ->
                    val rad = anglesDeg[idx] * (PI / 180.0)
                    val dx = (62f * cos(rad)).dp
                    val dy = (62f * sin(rad) - 4f).dp
                    val isSelected = state.mode == m
                    Text(
                        text = m.label,
                        style = PedalTypography.knobLegend.copy(
                            fontSize = 9.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold
                        ),
                        color = if (isSelected) activeAccent else labelColor.copy(alpha = 0.80f),
                        modifier = Modifier.offset(x = dx, y = dy).clickable { viewModel.setMode(m) }
                    )
                }
                RotaryKnob(
                    label = "MODE",
                    value = state.mode.ordinalCode.toFloat() / 5f,
                    defaultValue = UiDelayMode.ANALOG.ordinalCode.toFloat() / 5f,
                    readoutText = state.mode.label,
                    onValueChange = { norm -> viewModel.setMode(UiDelayMode.entries[(norm * 5f).toInt().coerceIn(0, 5)]) },
                    knobSize = modeKnobSize,
                    labelColor = labelColor,
                    arcColor = activeAccent,
                    discreteSteps = 6
                )
            }

            PingPongToggle(
                enabled = state.isPingPong,
                delayTimeMs = state.delayTimeMs,
                darkText = !state.darkStudioTheme,
                onToggle = viewModel::togglePingPong,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 12.dp)
            )
        }

        StompSwitch(
            isBypassed = state.isBypassed,
            isTapTempoMode = state.isTapTempoMode,
            onTap = viewModel::onStompTap,
            onLongPressTapTempo = viewModel::onStompLongPress,
            badgeText = "DD7X",
            height = stompHeight
        )
    }
}

@Composable
private fun RV6XReverbPedalCard(
    state: PedalUiState,
    ledPulse: Float,
    upperKnobSize: Dp,
    modeKnobSize: Dp,
    stompHeight: Dp,
    viewModel: PedalViewModel
) {
    val colors = LocalPedalColors.current
    // Metallic Gunmetal Charcoal Chassis + Brushed Silver-Steel Upper Plate (matching RV-6X preview)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF42474F), Color(0xFF282C32), Color(0xFF1A1D22))))
            .border(2.dp, Color(0xFF6B727D), RoundedCornerShape(18.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Brushed Silver-Steel Arched Control Plate
        Box(modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp)) {
            Canvas(modifier = Modifier.matchParentSize()) {
                drawArchedPlate(
                    brush = Brush.verticalGradient(listOf(Color(0xFFD5D9DF), Color(0xFFB3B8C0), Color(0xFF8E95A0))),
                    arcColor = Color(0xFF22262C).copy(alpha = 0.45f)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 7.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(11.dp)
                        .alpha(if (!state.rvBypassed) ledPulse else 1f)
                        .clip(CircleShape)
                        .background(if (!state.rvBypassed) colors.ledActiveRed else Color(0xFF4A4F57))
                        .border(1.dp, Color.White.copy(alpha = 0.65f), CircleShape)
                )
                Text("CHECK", style = PedalTypography.knobLegend, color = Color(0xFF1A1E24))
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 12.dp, start = 6.dp, end = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RotaryKnob(
                    label = "E.LEVEL",
                    value = state.rvLevel,
                    defaultValue = 0.42f,
                    readoutText = "${(state.rvLevel * 100).toInt()}%",
                    onValueChange = viewModel::setRvLevel,
                    knobSize = upperKnobSize,
                    labelColor = Color(0xFF181C22),
                    arcColor = Color(0xFF28303B),
                    modifier = Modifier.offset(y = 8.dp)
                )
                RotaryKnob(
                    label = "TONE",
                    value = state.rvTone,
                    defaultValue = 0.58f,
                    readoutText = "${(state.rvTone * 100).toInt()}%",
                    onValueChange = viewModel::setRvTone,
                    knobSize = upperKnobSize,
                    labelColor = Color(0xFF181C22),
                    arcColor = Color(0xFF28303B),
                    modifier = Modifier.offset(y = (-7).dp)
                )
                RotaryKnob(
                    label = "TIME",
                    value = state.rvTime,
                    defaultValue = 0.52f,
                    readoutText = "%.1fs".format(0.5f + state.rvTime * 7.5f),
                    onValueChange = viewModel::setRvTime,
                    knobSize = upperKnobSize,
                    labelColor = Color(0xFF181C22),
                    arcColor = Color(0xFF28303B),
                    modifier = Modifier.offset(y = 8.dp)
                )
            }
        }

        // Center 8-Mode RV-6X Selector Dial
        Box(modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.matchParentSize()) {
                drawScrewHead(Offset(10.dp.toPx(), size.height - 10.dp.toPx()), 6.dp.toPx())
                drawScrewHead(Offset(size.width - 10.dp.toPx(), size.height - 10.dp.toPx()), 6.dp.toPx())
            }

            Box(modifier = Modifier.align(Alignment.Center).offset(y = (-4).dp), contentAlignment = Alignment.Center) {
                val modes = UiReverbMode.entries
                val anglesDeg = listOf(150f, 182f, 214f, 245f, 295f, 326f, 358f, 30f)
                modes.forEachIndexed { idx, m ->
                    val rad = anglesDeg[idx] * (PI / 180.0)
                    val rx = 86f
                    val ry = 64f
                    val dx = (rx * cos(rad)).dp
                    val dy = (ry * sin(rad) - 4f).dp
                    val isSelected = state.rvMode == m
                    Text(
                        text = m.label,
                        style = PedalTypography.knobLegend.copy(
                            fontSize = 8.5.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold
                        ),
                        color = if (isSelected) Color(0xFFE6C27A) else Color(0xFFD5DCE6).copy(alpha = 0.85f),
                        modifier = Modifier.offset(x = dx, y = dy).clickable { viewModel.setRvMode(m) }
                    )
                }

                RotaryKnob(
                    label = "MODE",
                    value = state.rvMode.ordinalCode.toFloat() / 7f,
                    defaultValue = UiReverbMode.HALL.ordinalCode.toFloat() / 7f,
                    readoutText = state.rvMode.label,
                    onValueChange = { norm -> viewModel.setRvMode(UiReverbMode.entries[(norm * 7f).toInt().coerceIn(0, 7)]) },
                    knobSize = modeKnobSize,
                    labelColor = Color(0xFFE6ECF5),
                    arcColor = Color(0xFFE6C27A),
                    discreteSteps = 8
                )
            }
        }

        StompSwitch(
            isBypassed = state.rvBypassed,
            isTapTempoMode = false,
            onTap = viewModel::toggleRvBypass,
            onLongPressTapTempo = viewModel::toggleRvBypass,
            badgeText = "RV6X",
            height = stompHeight
        )
    }
}

private fun DrawScope.drawArchedPlate(brush: Brush, arcColor: Color) {
    val w = size.width
    val h = size.height
    val r = 12.dp.toPx()
    val archW = w * 0.44f
    val archH = 20.dp.toPx()

    val path = Path().apply {
        moveTo(r, 0f)
        lineTo(w - r, 0f)
        quadraticTo(w, 0f, w, r)
        lineTo(w, h - r)
        quadraticTo(w, h, w - r, h)
        lineTo((w + archW) * 0.5f, h)
        quadraticTo(w * 0.5f, h - archH * 1.85f, (w - archW) * 0.5f, h)
        lineTo(r, h)
        quadraticTo(0f, h, 0f, h - r)
        lineTo(0f, r)
        quadraticTo(0f, 0f, r, 0f)
        close()
    }
    drawPath(path = path, brush = brush)
    drawScrewHead(Offset(12.dp.toPx(), 12.dp.toPx()), 6.dp.toPx())
    drawScrewHead(Offset(w - 12.dp.toPx(), 12.dp.toPx()), 6.dp.toPx())
    drawArc(
        color = arcColor,
        startAngle = 200f,
        sweepAngle = 140f,
        useCenter = false,
        topLeft = Offset(w * 0.14f, h * 0.10f),
        size = Size(w * 0.72f, h * 0.85f),
        style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
    )
}

private fun DrawScope.drawScrewHead(center: Offset, radius: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(Color(0xFFE0E6EE), Color(0xFF5D6572)), center = center, radius = radius),
        radius = radius,
        center = center
    )
    val d = radius * 0.52f
    drawLine(Color(0xFF23272E), Offset(center.x - d, center.y - d), Offset(center.x + d, center.y + d), strokeWidth = 1.5f)
    drawLine(Color(0xFF23272E), Offset(center.x + d, center.y - d), Offset(center.x - d, center.y + d), strokeWidth = 1.5f)
}

@Composable
private fun PedalSwitcherTab(
    label: String,
    isSelected: Boolean,
    isEffectEngaged: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalPedalColors.current
    val bg = if (isSelected) {
        Brush.horizontalGradient(listOf(Color(0xFF7B5535), Color(0xFF533720)))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF251B14), Color(0xFF1D150F)))
    }
    Row(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(bg)
            .border(1.dp, colors.bronzeBorderGold.copy(alpha = if (isSelected) 0.95f else 0.3f), RoundedCornerShape(15.dp))
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(if (isEffectEngaged) colors.ledActiveRed else Color(0xFF5A626E))
        )
        Text(
            text = label,
            style = PedalTypography.knobLegend.copy(fontSize = 10.sp),
            color = if (isSelected) colors.bronzeTextPrimary else colors.bronzeTextMuted
        )
    }
}

@Composable
private fun BronzeSystemPill(
    text: String,
    active: Boolean,
    showProBadge: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalPedalColors.current
    val pillBrush = if (active) {
        Brush.verticalGradient(listOf(Color(0xFF7B5434), Color(0xFF4F341E)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF443123), Color(0xFF291D14)))
    }
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(33.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(pillBrush)
                .border(1.dp, colors.bronzeBorderGold.copy(alpha = if (active) 0.95f else 0.6f), RoundedCornerShape(17.dp))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = PedalTypography.captionMeta.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium),
                color = colors.bronzeTextPrimary,
                maxLines = 1
            )
        }
        if (showProBadge) {
            Text(
                text = "PRO",
                style = PedalTypography.knobLegend.copy(fontSize = 7.sp, lineHeight = 8.sp),
                color = Color(0xFF1F140B),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-2).dp, y = (-5).dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFE0B86A))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}
