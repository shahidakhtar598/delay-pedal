package com.naatdelay.dd7.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.data.repository.LicenseUiStatus
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    licenseStatus: LicenseUiStatus,
    antiBoomCut: Boolean,
    pingPongWidth: Float,
    onAntiBoomChange: (Boolean) -> Unit,
    onPingPongWidthChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalPedalColors.current
    val deviceId = licenseStatus.deviceIdentity?.shortId ?: "SHD-0000-0000"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = colors.bronzeSheetBg,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, colors.bronzeBorderGold.copy(alpha = 0.7f), RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF332419), Color(0xFF1F160F)))
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "App Settings",
                style = PedalTypography.headingSheet,
                color = colors.bronzeTextPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Brushed Bronze Pro License Banner Card matching mockup
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF7B5535), Color(0xFF4F341E))))
                    .border(1.dp, colors.bronzeBorderGold, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text("Pro License Active", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                Text(deviceId, style = PedalTypography.monoReadout, color = Color(0xFFEBD9C3))
                if (licenseStatus.userProfile.fullName.isNotBlank()) {
                    Text(
                        "${licenseStatus.userProfile.fullName} (@${licenseStatus.userProfile.username})",
                        style = PedalTypography.captionMeta,
                        color = colors.bronzeTextMuted
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Anti-Boom Vocal Cut", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                    Text("210 Hz HPF + 350 Hz notch", style = PedalTypography.captionMeta, color = colors.bronzeTextMuted)
                }
                Switch(
                    checked = antiBoomCut,
                    onCheckedChange = onAntiBoomChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFFFF6E8),
                        checkedTrackColor = Color(0xFFB38B59),
                        uncheckedThumbColor = Color(0xFF9E8A75),
                        uncheckedTrackColor = Color(0xFF3B2B1F)
                    )
                )
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Ping-Pong Stereo Width", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                    Text("${(pingPongWidth * 100).toInt()}%", style = PedalTypography.monoReadout, color = colors.bronzeBorderGold)
                }
                Slider(
                    value = pingPongWidth,
                    onValueChange = onPingPongWidthChange,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFFFF2DD),
                        activeTrackColor = colors.bronzeBorderGold,
                        inactiveTrackColor = Color(0xFF4A3628)
                    )
                )
            }
        }
    }
}
