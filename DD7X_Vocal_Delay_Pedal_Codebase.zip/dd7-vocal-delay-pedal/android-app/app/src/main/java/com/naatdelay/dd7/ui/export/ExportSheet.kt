package com.naatdelay.dd7.ui.export

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.audio.ExportForegroundService
import com.naatdelay.dd7.audio.ExportServiceState
import com.naatdelay.dd7.audio.NativeAudioBridge
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(
    defaultFileName: String,
    hasAudioLoaded: Boolean,
    isProActivated: Boolean,
    exportState: ExportServiceState,
    onStartExport: (String, Int) -> Unit,
    onCancelExport: () -> Unit,
    onOpenActivation: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalPedalColors.current
    val context = LocalContext.current
    var fileName by remember(defaultFileName) { mutableStateOf(defaultFileName) }
    var selectedFormat by remember { mutableIntStateOf(NativeAudioBridge.FORMAT_WAV_16) }

    val formats = listOf(
        NativeAudioBridge.FORMAT_MP3_192 to "MP3 (192k)",
        NativeAudioBridge.FORMAT_MP3_320 to "MP3 (320k - HQ)",
        NativeAudioBridge.FORMAT_WAV_16 to "WAV (16-bit - Lossless)"
    )

    ModalBottomSheet(
        onDismissRequest = {
            ExportForegroundService.resetState()
            onDismiss()
        },
        containerColor = colors.bronzeSheetBg,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, colors.bronzeBorderGold.copy(alpha = 0.7f), RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF332419), Color(0xFF1F160F)))
                )
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Export Studio Audio",
                style = PedalTypography.headingSheet,
                color = colors.bronzeTextPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = fileName,
                onValueChange = { fileName = it },
                label = { Text("Output Filename", color = colors.bronzeTextMuted) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = colors.bronzeTextPrimary,
                    unfocusedTextColor = colors.bronzeTextPrimary,
                    focusedBorderColor = colors.bronzeBorderGold,
                    unfocusedBorderColor = colors.bronzeBorderGold.copy(alpha = 0.45f)
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // 3 Stacked Format Cards matching 6f7a0641.png
            formats.forEach { (code, label) ->
                val active = selectedFormat == code
                val bg = if (active) {
                    Brush.horizontalGradient(listOf(Color(0xFF7B5535), Color(0xFF533720)))
                } else {
                    Brush.horizontalGradient(listOf(Color(0xFF2B1F16), Color(0xFF241912)))
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(bg)
                        .border(1.dp, colors.bronzeBorderGold.copy(alpha = if (active) 0.95f else 0.4f), RoundedCornerShape(12.dp))
                        .clickable { selectedFormat = code }
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, colors.bronzeBorderGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (active) {
                            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(colors.bronzeTextPrimary))
                        }
                    }
                    Text(label, style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                }
            }

            when (exportState) {
                is ExportServiceState.Running -> {
                    LinearProgressIndicator(
                        progress = { exportState.progressPercent / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = colors.bronzeBorderGold
                    )
                    Text(
                        "Rendering offline + echo tail... ${exportState.progressPercent}%",
                        style = PedalTypography.monoReadout,
                        color = colors.bronzeTextMuted
                    )
                }
                is ExportServiceState.Completed -> {
                    Text(
                        "Saved: Music/DD7_Vocal_Exports/${exportState.fileName} (+${exportState.tailMs} ms tail)",
                        style = PedalTypography.captionMeta,
                        color = colors.ledTempoGreen
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF7B5535), Color(0xFF5A3B22))))
                            .border(1.dp, colors.bronzeBorderGold, RoundedCornerShape(14.dp))
                            .clickable {
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = if (exportState.fileName.endsWith(".wav")) "audio/wav" else "audio/mpeg"
                                    putExtra(Intent.EXTRA_STREAM, exportState.outputUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(share, "Share Naat Audio"))
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("SHARE TO WHATSAPP / SOCIAL", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                    }
                }
                is ExportServiceState.Failed -> {
                    Text(exportState.errorMessage, style = PedalTypography.captionMeta, color = colors.ledActiveRed)
                }
                ExportServiceState.Idle -> {}
            }

            // Bottom CANCEL & EXPORT NOW side-by-side pills matching mockup
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF3A291D))
                        .border(1.dp, colors.bronzeBorderGold.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                        .clickable {
                            if (exportState is ExportServiceState.Running) onCancelExport() else onDismiss()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text("CANCEL", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            if (hasAudioLoaded) Brush.horizontalGradient(listOf(Color(0xFF8C623D), Color(0xFF5E3F24)))
                            else Brush.horizontalGradient(listOf(Color(0xFF3D322A), Color(0xFF332922)))
                        )
                        .border(1.dp, colors.bronzeBorderGold, RoundedCornerShape(22.dp))
                        .clickable(enabled = hasAudioLoaded) {
                            onStartExport(fileName.ifBlank { "Naat_DD7X" }, selectedFormat)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text("EXPORT NOW", style = PedalTypography.bodyPrimary, color = colors.bronzeTextPrimary)
                }
            }
        }
    }
}
