package com.naatdelay.dd7.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "presets",
    indices = [Index(value = ["name"], unique = true)]
)
data class PresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    @ColumnInfo(name = "is_factory") val isFactory: Boolean = false,
    @ColumnInfo(name = "delay_mode") val delayMode: String,
    @ColumnInfo(name = "effect_level") val effectLevel: Float,
    val feedback: Float,
    @ColumnInfo(name = "delay_time_ms") val delayTimeMs: Float,
    @ColumnInfo(name = "is_ping_pong") val isPingPong: Boolean = false,
    @ColumnInfo(name = "ping_pong_width") val pingPongWidth: Float = 0.85f,
    @ColumnInfo(name = "anti_boom_cut") val antiBoomCut: Boolean = true,
    @ColumnInfo(name = "rv_mode") val rvMode: String = "HALL",
    @ColumnInfo(name = "rv_level") val rvLevel: Float = 0.42f,
    @ColumnInfo(name = "rv_tone") val rvTone: Float = 0.58f,
    @ColumnInfo(name = "rv_time") val rvTime: Float = 0.52f,
    @ColumnInfo(name = "rv_bypassed") val rvBypassed: Boolean = false,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long
)
