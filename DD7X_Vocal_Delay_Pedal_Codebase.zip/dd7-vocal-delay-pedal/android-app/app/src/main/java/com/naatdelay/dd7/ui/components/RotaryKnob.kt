package com.naatdelay.dd7.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.R
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography

@Composable
fun RotaryKnob(
    label: String,
    value: Float,
    defaultValue: Float,
    readoutText: String,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    knobSize: Dp = 64.dp,
    labelColor: Color = Color.White,
    arcColor: Color = Color(0xFF00E5FF),
    discreteSteps: Int? = null
) {
    val colors = LocalPedalColors.current
    val haptic = LocalHapticFeedback.current
    val dragRangePx = with(LocalDensity.current) { 190.dp.toPx() }

    var isDragging by remember { mutableStateOf(false) }
    var lastDetent by remember { mutableIntStateOf(-1) }

    val animatedValue by animateFloatAsState(
        targetValue = value.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "knobSweep"
    )
    val pressScale by animateFloatAsState(
        targetValue = if (isDragging) 1.07f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "knobScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-34).dp)
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = isDragging,
                    enter = fadeIn() + scaleIn(),
                    exit = fadeOut() + scaleOut()
                ) {
                    Box(
                        modifier = Modifier
                            .background(colors.bronzeBarBg, RoundedCornerShape(8.dp))
                            .border(1.dp, colors.bronzeBorderGold, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = readoutText,
                            style = PedalTypography.monoReadout,
                            color = colors.bronzeTextPrimary
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .size(knobSize + 12.dp)
                    .scale(pressScale)
                    .pointerInput(defaultValue) {
                        detectTapGestures(
                            onDoubleTap = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onValueChange(defaultValue)
                            }
                        )
                    }
                    .pointerInput(value, discreteSteps) {
                        var currentVal = value
                        detectVerticalDragGestures(
                            onDragStart = {
                                isDragging = true
                                currentVal = value
                            },
                            onDragEnd = { isDragging = false },
                            onDragCancel = { isDragging = false },
                            onVerticalDrag = { _, dragAmount ->
                                currentVal = (currentVal - dragAmount / dragRangePx).coerceIn(0f, 1f)
                                if (discreteSteps != null && discreteSteps > 1) {
                                    val idx = (currentVal * (discreteSteps - 1)).toInt()
                                        .coerceIn(0, discreteSteps - 1)
                                    if (idx != lastDetent) {
                                        lastDetent = idx
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    }
                                    onValueChange(idx.toFloat() / (discreteSteps - 1).toFloat())
                                } else {
                                    onValueChange(currentVal)
                                }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                // Glowing Outer Progress Bezel Ring
                Canvas(modifier = Modifier.size(knobSize + 8.dp)) {
                    val strokeW = 2.8.dp.toPx()
                    val pad = strokeW
                    val arcSize = Size(size.width - pad * 2, size.height - pad * 2)
                    val topLeft = Offset(pad, pad)

                    drawArc(
                        color = Color(0x38000000),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeW, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = arcColor,
                        startAngle = 135f,
                        sweepAngle = 270f * animatedValue,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeW, cap = StrokeCap.Round)
                    )
                }

                // Real 3D Brushed-Metal Hardware Knob PNG rotated smoothly (-135 deg to +135 deg)
                Image(
                    painter = painterResource(id = R.drawable.knob_3d_metal),
                    contentDescription = label,
                    modifier = Modifier
                        .size(knobSize)
                        .graphicsLayer {
                            rotationZ = -135f + 270f * animatedValue
                        }
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = PedalTypography.knobLegend,
            color = labelColor
        )
    }
}
