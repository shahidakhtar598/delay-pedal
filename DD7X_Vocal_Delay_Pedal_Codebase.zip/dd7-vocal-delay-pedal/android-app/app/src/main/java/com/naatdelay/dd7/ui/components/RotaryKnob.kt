package com.naatdelay.dd7.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.naatdelay.dd7.ui.theme.LocalPedalColors
import com.naatdelay.dd7.ui.theme.PedalTypography
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RotaryKnob(
    label: String,
    value: Float,
    defaultValue: Float,
    readoutText: String,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    knobSize: Dp = 58.dp,
    labelColor: Color = Color.White,
    arcColor: Color = Color(0xFF00E5FF),
    discreteSteps: Int? = null
) {
    val colors = LocalPedalColors.current
    val haptic = LocalHapticFeedback.current
    val dragRangePx = with(LocalDensity.current) { 190.dp.toPx() }

    var isDragging by remember { mutableStateOf(false) }
    var lastDetent by remember { mutableIntStateOf(-1) }

    val animatedValue by animateFloatAsState(
        targetValue = value.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "knobSweep"
    )
    val pressScale by animateFloatAsState(
        targetValue = if (isDragging) 1.07f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "knobScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(contentAlignment = Alignment.Center) {
            AnimatedVisibility(
                visible = isDragging,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-34).dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(colors.bronzeBarBg, RoundedCornerShape(8.dp))
                        .border(1.dp, colors.bronzeBorderGold, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = readoutText,
                        style = PedalTypography.monoReadout,
                        color = colors.bronzeTextPrimary
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(knobSize + 10.dp)
                    .scale(pressScale)
                    .pointerInput(defaultValue) {
                        detectTapGestures(
                            onDoubleTap = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onValueChange(defaultValue)
                            }
                        )
                    }
                    .pointerInput(value, discreteSteps) {
                        var currentVal = value
                        detectVerticalDragGestures(
                            onDragStart = {
                                isDragging = true
                                currentVal = value
                            },
                            onDragEnd = { isDragging = false },
                            onDragCancel = { isDragging = false },
                            onVerticalDrag = { _, dragAmount ->
                                currentVal = (currentVal - dragAmount / dragRangePx).coerceIn(0f, 1f)
                                if (discreteSteps != null && discreteSteps > 1) {
                                    val idx = (currentVal * (discreteSteps - 1)).toInt()
                                        .coerceIn(0, discreteSteps - 1)
                                    if (idx != lastDetent) {
                                        lastDetent = idx
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    }
                                    onValueChange(idx.toFloat() / (discreteSteps - 1).toFloat())
                                } else {
                                    onValueChange(currentVal)
                                }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(knobSize)) {
                    val strokeW = 3.dp.toPx()
                    val pad = strokeW + 2.dp.toPx()
                    val arcSize = Size(size.width - pad * 2, size.height - pad * 2)
                    val topLeft = Offset(pad, pad)

                    drawArc(
                        color = Color(0x33000000),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeW, cap = StrokeCap.Round)
                    )

                    drawArc(
                        color = arcColor,
                        startAngle = 135f,
                        sweepAngle = 270f * animatedValue,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeW, cap = StrokeCap.Round)
                    )

                    val radius = (size.minDimension / 2f) - pad - 2.dp.toPx()
                    val center = Offset(size.width / 2f, size.height / 2f)

                    // Outer metallic bezel ring
                    drawCircle(
                        brush = Brush.linearGradient(
                            listOf(Color(0xFF4B525E), Color(0xFF171A20))
                        ),
                        radius = radius,
                        center = center
                    )
                    // Inner brushed cap
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0xFF353B45), Color(0xFF15181E)),
                            center = center,
                            radius = radius * 0.86f
                        ),
                        radius = radius * 0.86f,
                        center = center
                    )

                    val angleDeg = 135f + 270f * animatedValue
                    val rad = angleDeg * (PI / 180.0)
                    val innerR = radius * 0.25f
                    val outerR = radius * 0.84f
                    drawLine(
                        color = Color.White,
                        start = Offset(
                            center.x + (innerR * cos(rad)).toFloat(),
                            center.y + (innerR * sin(rad)).toFloat()
                        ),
                        end = Offset(
                            center.x + (outerR * cos(rad)).toFloat(),
                            center.y + (outerR * sin(rad)).toFloat()
                        ),
                        strokeWidth = 2.6.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = PedalTypography.knobLegend,
            color = labelColor
        )
    }
}
