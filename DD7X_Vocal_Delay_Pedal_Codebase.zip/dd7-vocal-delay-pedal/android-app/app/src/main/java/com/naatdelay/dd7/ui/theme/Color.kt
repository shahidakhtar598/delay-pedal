package com.naatdelay.dd7.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class PedalColors(
    val bgChassis: Color,
    val pedalBodyTop: Color,
    val pedalBodyBottom: Color,
    val pedalCobaltStripe: Color,
    val surfaceCard: Color,
    val surfaceRecessed: Color,
    val stompPadBg: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accentCobalt: Color,
    val accentPingPong: Color,
    val ledActiveRed: Color,
    val ledTempoGreen: Color,
    val statusWarning: Color,
    val borderSubtle: Color,
    // Official Brownish-Bronze Premium Tokens (for System Bar & Bottom Sheets)
    val bronzeBarBg: Color,
    val bronzePillBg: Color,
    val bronzePillActive: Color,
    val bronzeBorderGold: Color,
    val bronzeSheetBg: Color,
    val bronzeCardBg: Color,
    val bronzeTextPrimary: Color,
    val bronzeTextMuted: Color,
    // Light Brownish Onboarding Gate Tokens
    val lightBrownBg: Color,
    val lightBrownCard: Color,
    val lightBrownField: Color,
    val lightBrownAccent: Color,
    val lightBrownText: Color,
    val lightBrownSubtext: Color
)

val ClassicSilverColors = PedalColors(
    bgChassis         = Color(0xFF14110F),
    pedalBodyTop      = Color(0xFFF4F3EE),
    pedalBodyBottom   = Color(0xFFE3E0D6),
    pedalCobaltStripe = Color(0xFF1656B8),
    surfaceCard       = Color(0xFFFFFFFF),
    surfaceRecessed   = Color(0xFFE4E8F0),
    stompPadBg        = Color(0xFF181A1F),
    textPrimary       = Color(0xFF111418),
    textSecondary     = Color(0xFF5A6475),
    accentCobalt      = Color(0xFF1565C0),
    accentPingPong    = Color(0xFF00ACC1),
    ledActiveRed      = Color(0xFFE53935),
    ledTempoGreen     = Color(0xFF00C853),
    statusWarning     = Color(0xFFEF6C00),
    borderSubtle      = Color(0xFFD5DCE6),
    bronzeBarBg       = Color(0xFF231811),
    bronzePillBg      = Color(0xFF36251B),
    bronzePillActive  = Color(0xFF6A482B),
    bronzeBorderGold  = Color(0xFFC59B5F),
    bronzeSheetBg     = Color(0xFF281C14),
    bronzeCardBg      = Color(0xFF36261C),
    bronzeTextPrimary = Color(0xFFF6EFE6),
    bronzeTextMuted   = Color(0xFFCBBBA8),
    lightBrownBg      = Color(0xFFF7F1E8),
    lightBrownCard    = Color(0xFFFFFBF5),
    lightBrownField   = Color(0xFFEFE4D4),
    lightBrownAccent  = Color(0xFF6D4C3D),
    lightBrownText    = Color(0xFF2E1E16),
    lightBrownSubtext = Color(0xFF6E574B)
)

val DarkStudioColors = PedalColors(
    bgChassis         = Color(0xFF0F0D0B),
    pedalBodyTop      = Color(0xFF1F232A),
    pedalBodyBottom   = Color(0xFF13161B),
    pedalCobaltStripe = Color(0xFF144B9E),
    surfaceCard       = Color(0xFF1C2026),
    surfaceRecessed   = Color(0xFF0B0D10),
    stompPadBg        = Color(0xFF121418),
    textPrimary       = Color(0xFFF4F6F9),
    textSecondary     = Color(0xFF9AA4B2),
    accentCobalt      = Color(0xFF00E5FF),
    accentPingPong    = Color(0xFF00E5FF),
    ledActiveRed      = Color(0xFFFF5252),
    ledTempoGreen     = Color(0xFF00E676),
    statusWarning     = Color(0xFFFFB74D),
    borderSubtle      = Color(0xFF2C323C),
    bronzeBarBg       = Color(0xFF1E150F),
    bronzePillBg      = Color(0xFF302118),
    bronzePillActive  = Color(0xFF6A482B),
    bronzeBorderGold  = Color(0xFFC59B5F),
    bronzeSheetBg     = Color(0xFF241912),
    bronzeCardBg      = Color(0xFF33241A),
    bronzeTextPrimary = Color(0xFFF6EFE6),
    bronzeTextMuted   = Color(0xFFCBBBA8),
    lightBrownBg      = Color(0xFFF7F1E8),
    lightBrownCard    = Color(0xFFFFFBF5),
    lightBrownField   = Color(0xFFEFE4D4),
    lightBrownAccent  = Color(0xFF6D4C3D),
    lightBrownText    = Color(0xFF2E1E16),
    lightBrownSubtext = Color(0xFF6E574B)
)

val LocalPedalColors = staticCompositionLocalOf { ClassicSilverColors }
